
프로젝트 기본 정보
- 인텔리제이 기준
- JAVA VERSION
  - 1.8
- Plugin
  - lombok
  - mapstruct
- swagger url
  - http://localhost:8088/swagger-ui.html





```
screen -x X 
```

입력하여 현재 super 계정으로 구동중인 서버 로그 확인가능

``` 
nohup java -jar -Dspring.profiles.active=local ./apimain.war &
```

서버 실행

```
tail -f ./nohup.out
```

로그 확인