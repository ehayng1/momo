package kr.co.dk.sample.api.app.company.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class CompanyDAO {

    private static final Logger log = LogManager.getLogger(CompanyDAO.class);
    static final String NAMESAPCE =  "kr.co.dk.sample.api.app.company.mapper.CompanyDAO.";

    //	@Autowired
    private SqlSession sqlSession;

    //	@Qualifier("readOnlySqlSession")
    private SqlSessionTemplate readOnlySqlSession;

    public CompanyDAO(SqlSession sqlSession,SqlSessionTemplate readOnlySqlSession){
        this.sqlSession = sqlSession;
        this.readOnlySqlSession = readOnlySqlSession;
    }

    @Autowired
    Environment env;

    public Map<String, Object> selectCompanyCnt(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanyCnt:::");
        Map<String,Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectCompanyCnt", map);

        return result;
    }


    public Map<String, Object> selectSiteCnt(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectSiteCnt:::");
        Map<String,Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectSiteCnt", map);

        return result;
    }


    public Map<String, Object> selectRatingCnt(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectRatingCnt:::");
        Map<String,Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectRatingCnt", map);

        return result;
    }

    public List<Map> selectAllCompany(Map<String, Object> map) throws Exception{
        log.debug("+++++++++++++++++++++++++++++++++++++ selectAllCompany:::");
        List<Map> company = readOnlySqlSession.selectList(NAMESAPCE + "selectAllCompany", map);

        return company;
    }

    public Map<String, Object> selectCompanyInfo(Map<String, Object> map) throws Exception{
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanyInfo:::");
        Map<String,Object> company = readOnlySqlSession.selectOne(NAMESAPCE + "selectCompanyInfo", map);

        return company;
    }

    public List<Map> selectCompanySiteList(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanySiteList:::");
        List<Map> companySiteList = readOnlySqlSession.selectList(NAMESAPCE + "selectCompanySiteList", map);
        return companySiteList;
    }

    public List<Map> selectSiteList(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectSiteList:::");
        List<Map> companySiteList = readOnlySqlSession.selectList(NAMESAPCE + "selectSiteList", map);
        return companySiteList;
    }

    public Map<String, Object> selectCompanyEvaluate(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanyEvaluate:::");
        Map<String,Object> evaluate = readOnlySqlSession.selectOne(NAMESAPCE + "selectCompanyEvaluate", map);
        return evaluate;
    }

    public List<Map> selectCompanyRatingList(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanyRatingList:::");
        List<Map> companyRatingList = readOnlySqlSession.selectList(NAMESAPCE + "selectCompanyRatingList", map);
        return companyRatingList;
    }

    public Map<String, Object> selectSiteInfo(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectSiteInfo:::");
        Map<String, Object> detail = readOnlySqlSession.selectOne(NAMESAPCE + "selectSiteInfo", map);
        return detail;
    }

    public List<Map> selectSiteRatingList(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanyRatingList:::");
        List<Map> siteRatingList = readOnlySqlSession.selectList(NAMESAPCE + "selectSiteRatingList", map);
        return siteRatingList;
    }

    public List<Map> selectRatingList(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectRatingList:::");
        List<Map> siteRatingList = readOnlySqlSession.selectList(NAMESAPCE + "selectRatingList", map);
        return siteRatingList;
    }

    public Map<String, Object> selectCompanyIdx(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanyIdx:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectCompanyIdx", map);
        return result;
    }

    public int insertSiteRating(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ insertSiteRating:::");
        int result = readOnlySqlSession.insert(NAMESAPCE + "insertSiteRating", map);
        return result;
    }

    public int updateSiteRating(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateSiteRating:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateSiteRating", map);
        return result;
    }

    public int updateCompanyRating(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateCompanyRating:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateCompanyRating", map);
        return result;
    }

    public List<Map> selectCompanyStatisticsTotal() throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanyStatisticsTotal:::");
        List<Map> statistics = readOnlySqlSession.selectList(NAMESAPCE + "selectCompanyStatisticsTotal");
        return statistics;
    }

    public List<Map> selectCompanyStatisticsSafe() throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanyStatisticsSafe:::");
        List<Map> statistics = readOnlySqlSession.selectList(NAMESAPCE + "selectCompanyStatisticsSafe");
        return statistics;
    }

    public List<Map> selectCompanyStatisticsWelfare() throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanyStatisticsWelfare:::");
        List<Map> statistics = readOnlySqlSession.selectList(NAMESAPCE + "selectCompanyStatisticsWelfare");
        return statistics;
    }

    public List<Map> selectCompanyStatisticsHard() throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanyStatisticsHard:::");
        List<Map> statistics = readOnlySqlSession.selectList(NAMESAPCE + "selectCompanyStatisticsHard");
        return statistics;
    }

    public List<Map> selectCompanyStatisticsPayment() throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanyStatisticsPayment:::");
        List<Map> statistics = readOnlySqlSession.selectList(NAMESAPCE + "selectCompanyStatisticsPayment");
        return statistics;
    }

    public List<Map> selectCompanyStatisticsMeal() throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanyStatisticsMeal:::");
        List<Map> statistics = readOnlySqlSession.selectList(NAMESAPCE + "selectCompanyStatisticsMeal");
        return statistics;
    }

    public List<Map> selectCompanyStatisticsRest() throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectCompanyStatisticsRest:::");
        List<Map> statistics = readOnlySqlSession.selectList(NAMESAPCE + "selectCompanyStatisticsRest");
        return statistics;
    }

    public int writeCompany(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ writeCompany:::");
        int result = readOnlySqlSession.insert(NAMESAPCE + "writeCompany", map);
        return result;
    }

    public int updateCompany(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateCompany:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateCompany", map);
        return result;
    }

    public int deleteCompany(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ deleteCompany:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "deleteCompany", map);
        return result;
    }

    public int writeSite(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ writeSite:::");
        int result = readOnlySqlSession.insert(NAMESAPCE + "writeSite", map);
        return result;
    }

    public int updateSite(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateSite:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateSite", map);
        return result;
    }

    public int deleteSite(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ deleteSite:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "deleteSite", map);
        return result;
    }

    public int deleteRating(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ deleteRating:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "deleteRating", map);
        return result;
    }

}
