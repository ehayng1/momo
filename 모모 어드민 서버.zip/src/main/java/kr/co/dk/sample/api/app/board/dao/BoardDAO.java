package kr.co.dk.sample.api.app.board.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class BoardDAO {

    private static final Logger log = LogManager.getLogger(BoardDAO.class);
    static final String NAMESAPCE = "kr.co.dk.sample.api.app.board.mapper.BoardDAO.";

    //	@Autowired
    private SqlSession sqlSession;

    //	@Qualifier("readOnlySqlSession")
    private SqlSessionTemplate readOnlySqlSession;

    public BoardDAO(SqlSession sqlSession, SqlSessionTemplate readOnlySqlSession) {
        this.sqlSession = sqlSession;
        this.readOnlySqlSession = readOnlySqlSession;
    }

    @Autowired
    Environment env;


    public Map<String, Object> selectBoardCnt(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectBoardCnt:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectBoardCnt", map);

        return result;
    }

    public Map<String, Object> selectReplyCnt(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectReplyCnt:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectReplyCnt", map);

        return result;
    }

    public List<Map> selectAllBoard(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectAllBoard:::");
        List<Map> board = readOnlySqlSession.selectList(NAMESAPCE + "selectAllBoard", map);

        return board;
    }

    public int updateBoard(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateBoard:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateBoard", map);

        return result;
    }

    public int increaseViewCount(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ increaseViewCount:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "increaseViewCount", map);

        return result;
    }

    public Map<String, Object> selectBoardDetail(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectBoardDetail:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectBoardDetail", map);

        return result;
    }

    public List<Map> selectBoardReply(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectBoardReply:::");
        List<Map> result = readOnlySqlSession.selectList(NAMESAPCE + "selectBoardReply", map);

        return result;
    }

    public List<Map> selectReply(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectReply:::");
        List<Map> result = readOnlySqlSession.selectList(NAMESAPCE + "selectReply", map);

        return result;
    }

    public int insertBoard(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ insertBoard:::");
        int result = readOnlySqlSession.insert(NAMESAPCE + "insertBoard", map);

        return result;
    }

    public int insertReply(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ insertReply:::");
        int result = readOnlySqlSession.insert(NAMESAPCE + "insertReply", map);

        return result;
    }

    public List<Map> searchBoard(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ searchBoard:::");
        List<Map> result = readOnlySqlSession.selectList(NAMESAPCE + "searchBoard", map);

        return result;
    }

    public int deleteBoard(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ deleteBoard:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "deleteBoard", map);

        return result;
    }

    public int deleteReply(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ deleteReply:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "deleteReply", map);

        return result;
    }
}
