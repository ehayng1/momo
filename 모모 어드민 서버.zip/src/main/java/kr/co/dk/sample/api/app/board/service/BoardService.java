package kr.co.dk.sample.api.app.board.service;

import kr.co.dk.sample.api.app.board.dao.BoardDAO;
import kr.co.dk.sample.api.common.model.Paging;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Properties;

@Service
public class BoardService {

    private static final Logger log = LogManager.getLogger(BoardService.class);

    @Autowired
    BoardDAO boardDAO;

    @Qualifier("prop")
    private Properties properties;

    @Autowired
    Environment env;

    public Paging setBoardPaging(Map<String, Object> paramMap) throws Exception {
        Map<String, Object> map = boardDAO.selectBoardCnt(paramMap);
        int totalCount = ((Long) map.get("cnt")).intValue();
        int pageNo = 1;
        int pageSize = 10;

        Paging paging = new Paging();

        try {

            if (paramMap.get("page_size") != null) {
                String sPageSize = (String) paramMap.get("page_size");
                try {
                    pageSize = Integer.parseInt(sPageSize);
                }catch (Exception e) {}
            }

            if (paramMap.get("pageNo") != null) {
                String sPageNo = (String) paramMap.get("pageNo");
                try {
                    pageNo = Integer.parseInt(sPageNo);
                }catch (Exception e) {}
            }

            paging.setPageNo(pageNo);
            paging.setPageSize(pageSize);
            paging.setTotalCount(totalCount);
        } catch (Exception e) {
            throw e;
        }

        paramMap.put("start_idx", paging.getStartIndex());
        paramMap.put("page_size", paging.getPageSize());

        return paging;
    }

    public Paging setReplyPaging(Map<String, Object> paramMap) throws Exception {
        Map<String, Object> map = boardDAO.selectReplyCnt(paramMap);
        int totalCount = ((Long) map.get("cnt")).intValue();
        int pageNo = 1;
        int pageSize = 10;

        Paging paging = new Paging();

        try {

            if (paramMap.get("page_size") != null) {
                String sPageSize = (String) paramMap.get("page_size");
                try {
                    pageSize = Integer.parseInt(sPageSize);
                }catch (Exception e) {}
            }

            if (paramMap.get("pageNo") != null) {
                String sPageNo = (String) paramMap.get("pageNo");
                try {
                    pageNo = Integer.parseInt(sPageNo);
                }catch (Exception e) {}
            }

            paging.setPageNo(pageNo);
            paging.setPageSize(pageSize);
            paging.setTotalCount(totalCount);
        } catch (Exception e) {
            throw e;
        }

        paramMap.put("start_idx", paging.getStartIndex());
        paramMap.put("page_size", paging.getPageSize());

        return paging;
    }

    public List<Map> selectAllBoard(Map<String, Object> map) throws Exception {
        return boardDAO.selectAllBoard(map);
    }

    public int updateBoard(Map<String, Object> map) throws Exception {
        return boardDAO.updateBoard(map);
    }

    public int increaseViewCount(Map<String, Object> map) throws Exception {
        return boardDAO.increaseViewCount(map);
    }

    public Map<String, Object> selectBoardDetail(Map<String, Object> map) throws Exception {
        return boardDAO.selectBoardDetail(map);
    }

    public List<Map> selectBoardReply(Map<String, Object> map) throws Exception {
        return boardDAO.selectBoardReply(map);
    }

    public List<Map> selectReply(Map<String, Object> map) throws Exception {
        return boardDAO.selectReply(map);
    }

    public int insertBoard(Map<String, Object> map) throws Exception {
        return boardDAO.insertBoard(map);
    }

    public int insertReply(Map<String, Object> map) throws Exception {
        return boardDAO.insertReply(map);
    }

    public List<Map> searchBoard(Map<String, Object> map) throws Exception {
        return boardDAO.searchBoard(map);
    }

    public int deleteBoard(Map<String, Object> map) throws Exception {
        return boardDAO.deleteBoard(map);
    }

    public int deleteReply(Map<String, Object> map) throws Exception {
        return boardDAO.deleteReply(map);
    }
}
