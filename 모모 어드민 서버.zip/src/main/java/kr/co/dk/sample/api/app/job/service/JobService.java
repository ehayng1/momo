package kr.co.dk.sample.api.app.job.service;

import kr.co.dk.sample.api.app.job.dao.JobDAO;
import kr.co.dk.sample.api.common.model.Paging;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Properties;

@Service
public class JobService {

    private static final Logger log = LogManager.getLogger(JobService.class);

    @Autowired
    JobDAO jobDAO;

    @Qualifier("prop")
    private Properties properties;

    @Autowired
    Environment env;

    public Paging setJobPaging(Map<String, Object> paramMap) throws Exception {
        Map<String, Object> map = jobDAO.selectJobCnt(paramMap);
        int totalCount = ((Long) map.get("cnt")).intValue();
        int pageNo = 1;
        int pageSize = 10;

        Paging paging = new Paging();

        try {

            if (paramMap.get("page_size") != null) {
                String sPageSize = (String) paramMap.get("page_size");
                try {
                    pageSize = Integer.parseInt(sPageSize);
                }catch (Exception e) {}
            }

            if (paramMap.get("pageNo") != null) {
                String sPageNo = (String) paramMap.get("pageNo");
                try {
                    pageNo = Integer.parseInt(sPageNo);
                }catch (Exception e) {}
            }

            paging.setPageNo(pageNo);
            paging.setPageSize(pageSize);
            paging.setTotalCount(totalCount);
        } catch (Exception e) {
            throw e;
        }

        paramMap.put("start_idx", paging.getStartIndex());
        paramMap.put("page_size", paging.getPageSize());

        return paging;
    }

    public List<Map> selectJobList(Map<String, Object> map) throws Exception {
        return jobDAO.selectJobList(map);
    }

    public Map<String, Object> selectJobDetail(Map<String, Object> map) throws Exception {
        return jobDAO.selectJobDetail(map);
    }

    public int updateJobOffer(Map<String, Object> map) throws Exception {
        return jobDAO.updateJobOffer(map);
    }

    public int updateJobSearch(Map<String, Object> map) throws Exception {
        return jobDAO.updateJobSearch(map);
    }

    public int deleteJob(Map<String, Object> map) throws Exception {
        return jobDAO.deleteJob(map);
    }

    public int allowJob(Map<String, Object> map) throws Exception {
        return jobDAO.allowJob(map);
    }

}
