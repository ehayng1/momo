package kr.co.dk.sample.api.app.board.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class BoardDTO {
    private String issueTitle;
    private String issueContent;
    private MultipartFile issueImage;
}
