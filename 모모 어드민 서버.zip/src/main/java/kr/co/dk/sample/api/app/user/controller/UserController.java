package kr.co.dk.sample.api.app.user.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.co.dk.sample.api.app.user.service.UserService;
import kr.co.dk.sample.api.common.model.ApiResponse;
import kr.co.dk.sample.api.common.model.ErrorCode;
import kr.co.dk.sample.api.common.model.Paging;
import kr.co.dk.sample.api.config.security.JwtTokenProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Tag(name = "사용자")
@RestController
public class UserController {
    private static final Logger log = LogManager.getLogger(UserController.class);

    @Autowired
    UserService userService;

    @Autowired
    JwtTokenProvider jwtTokenProvider;

    @Operation(summary = "유저 리스트", description = "")
    @GetMapping("/api/v1/admin/user/list/{pageNo}")
    public ResponseEntity<?> selectUserList(
            HttpServletRequest request,
            @Parameter(name = "pageNo", description = "페이지번호", in = ParameterIn.PATH)
            @PathVariable String pageNo) throws Throwable {
        log.info("=============================START========================================== in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (pageNo == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("pageNo", pageNo);

            Paging paging = userService.setUserPaging(jwtMap);
            List<Map> result = userService.selectUserList(jwtMap);

            rtnMap.put("result", result);
            rtnMap.put("paging", paging);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "유저 검색", description = "")
    @GetMapping("/api/v1/admin/user/search/{word}/{pageNo}")
    public ResponseEntity<?> selectUserList(
            HttpServletRequest request,
            @Parameter(name = "word", description = "검색어", in = ParameterIn.PATH)
            @PathVariable String word,
            @Parameter(name = "pageNo", description = "페이지번호", in = ParameterIn.PATH)
            @PathVariable String pageNo) throws Throwable {
        log.info("=============================START========================================== in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (pageNo == null || word == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("pageNo", pageNo);
            jwtMap.put("word", word);

            Paging paging = userService.setUserPaging(jwtMap);
            List<Map> result = userService.selectUserList(jwtMap);

            rtnMap.put("result", result);
            rtnMap.put("paging", paging);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "회원 상세")
    //맵핑주소 필터처리 필요
    @GetMapping("/api/v1/admin/user/detail/{idx}")
    public ResponseEntity<?> selectUserinfoList(
            HttpServletRequest request,
            @Parameter(name = "idx", description = "유저 인덱스", in = ParameterIn.PATH)
            @PathVariable String idx) throws Exception {

        Map<String, Object> rtnMap = new HashMap<String, Object>();

        try{

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if(idx == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            Map<String, Object> paramMap = new HashMap<>();
            jwtMap.put("idx", idx);

            Map<String, Object> result = userService.selectUserInfo(paramMap);
            rtnMap.put("result", result);

            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "유저 상태변경")
    @PutMapping("/api/v1/admin/user/update")
    public ResponseEntity<?> updateUser(
            @Schema(
                    description = "userIdx, status",
                    type = "array",
                    example = " {\"userIdx\" :\"1\" ,"
                            + "\"status\": \"0\"}")
            @RequestBody Map<String, Object> paramMap, HttpServletRequest request) {
        log.debug("=============================START= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (paramMap.get("userIdx") == null || paramMap.get("status") == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9998));
            }

            int result = userService.updateUser(paramMap);

            if (result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9999));
            } else {
                return ResponseEntity.ok(new ApiResponse(true, "success", "success", 200));
            }

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9999));
        }
    }
}
