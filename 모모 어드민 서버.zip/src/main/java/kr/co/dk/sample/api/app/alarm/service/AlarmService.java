package kr.co.dk.sample.api.app.alarm.service;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import kr.co.dk.sample.api.app.alarm.dao.AlarmDAO;
import kr.co.dk.sample.api.common.util.HeaderRequestInterceptor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.CompletableFuture;

import static kr.co.dk.sample.api.common.util.CommonUtil.makeForeach;

@Service
public class AlarmService {
    private static final Logger log = LogManager.getLogger(AlarmService.class);

    @Autowired
    AlarmDAO alarmDAO;

    @Qualifier("prop")
    private Properties properties;

    @Autowired
    Environment env;

    @Value("${firebase.server.key}")
    private String serverKey;

    private String apiUrl = "https://fcm.googleapis.com/fcm/send";


    public List<Map> selectAlarmList(Map<String, Object> map) throws Exception {
        return alarmDAO.selectAlarmList(map);
    }

    public int insertPush(Map<String, Object> map) throws Exception {
        int result = alarmDAO.insertPush(map);
        return result;
    }

    public boolean sendMessage(String token, String title, String body, HashMap<String, String> data){
        try {
            Notification notification= Notification.builder().setTitle(title).setBody(body).build();
            Message message = Message.builder().setToken(token).putAllData(data)
                    .setNotification(notification).build();
            String result = FirebaseMessaging.getInstance().send(message);
        } catch (FirebaseMessagingException e) {
            log.error("FirebaseMessagingException : {}", e);
        } catch (Exception e){
            log.error("Exception : {}", e);
        }

        return true;
    }

    public List<String> PeriodicNotificationJson(Map<String, Object> map) throws Exception {
        LocalDate localDate = LocalDate.now();

        String sampleData[] = {"device token value 1","device token value 2","device token value 3"};

        if (map.get("type").toString().equals("each")) {
            map.put("list", makeForeach(map.get("idx").toString()));
        }

        List<Map> fcmList = alarmDAO.getFcmList(map);

        if (fcmList.isEmpty()) {
            return null;
        } else {
            map.put("idxList", fcmList);
        }

        JSONObject body = new JSONObject();

        List<String> rtnList = new ArrayList<String>();

//        for(int i=0; i<sampleData.length; i++){
//            tokenlist.add(sampleData[i]);
//        }

        JSONArray array = new JSONArray();

        if (fcmList.size() > 9) {
            for(int i=0; i<fcmList.size(); i++) {
                array.put(fcmList.get(i).get("token_fcm").toString());
                if (array.length() > 9) {
                    body = new JSONObject();

                    body.put("registration_ids", array);

                    JSONObject notification = new JSONObject();
                    notification.put("title", map.get("title").toString());
                    notification.put("body", map.get("content").toString());

                    body.put("notification", notification);

                    rtnList.add(body.toString());

                    array = new JSONArray();
                } else if (i == fcmList.size() - 1) {
                    body = new JSONObject();

                    body.put("registration_ids", array);

                    JSONObject notification = new JSONObject();
                    notification.put("title", map.get("title").toString());
                    notification.put("body", map.get("content").toString());

                    body.put("notification", notification);

                    rtnList.add(body.toString());

                    array = new JSONArray();
                }
            }
        } else {
            for(int i=0; i<fcmList.size(); i++) {
                array.put(fcmList.get(i).get("token_fcm").toString());
            }
            body.put("registration_ids", array);

            JSONObject notification = new JSONObject();
            notification.put("title", map.get("title").toString());
            notification.put("body", map.get("content").toString());

            body.put("notification", notification);

            rtnList.add(body.toString());
        }

        return rtnList;
    }

}
