package kr.co.dk.sample.api.app.equip.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.co.dk.sample.api.app.equip.dto.LeaseDTO;
import kr.co.dk.sample.api.app.equip.dto.OwnerDTO;
import kr.co.dk.sample.api.app.equip.dto.RentalDTO;
import kr.co.dk.sample.api.app.equip.service.EquipService;
import kr.co.dk.sample.api.app.labor.dto.LaborDTO;
import kr.co.dk.sample.api.common.model.ApiResponse;
import kr.co.dk.sample.api.common.model.ErrorCode;
import kr.co.dk.sample.api.common.model.Paging;
import kr.co.dk.sample.api.common.util.S3Util;
import kr.co.dk.sample.api.config.security.JwtTokenProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static kr.co.dk.sample.api.common.util.CommonUtil.makeForeach;

@Tag(name="장비")
@RestController
public class EquipController {

    private static final Logger log = LogManager.getLogger(EquipController.class);

    @Autowired
    EquipService equipService;

    @Autowired
    JwtTokenProvider jwtTokenProvider;

    @Autowired
    S3Util s3Util;

    @Operation(summary = "임대/임차 목록 조회")
    @GetMapping("/api/v1/admin/equip/list/{type}/{pageNo}")
    public ResponseEntity<?> getEquipLRList(HttpServletRequest request,
                                          @Parameter(name = "type", description = "임대 = 0, 임차 = 1", in = ParameterIn.PATH)
                                          @PathVariable String type,
                                          @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
                                          @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == type || Integer.parseInt(type) > 1 || Integer.parseInt(type) < 0 || null == pageNo) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            Map<String, Object> paramMap = new HashMap<>();

            paramMap.put("type", type);
            paramMap.put("pageNo", pageNo);
            Paging pagingBoard = equipService.setEquipPaging(paramMap);
            List<Map> equipList = equipService.selectEquipList(paramMap);

            if(equipList == null || equipList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", equipList);
            rtnMap.put("paging", pagingBoard);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "장비 목록 조회")
    @GetMapping("/api/v1/admin/equip/list/{pageNo}")
    public ResponseEntity<?> getEquipList(HttpServletRequest request,
                                          @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
                                          @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == pageNo) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            Map<String, Object> paramMap = new HashMap<>();

            paramMap.put("pageNo", pageNo);
            Paging pagingBoard = equipService.setEquipPaging(paramMap);
            List<Map> equipList = equipService.selectEquipList(paramMap);

            if(equipList == null || equipList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", equipList);
            rtnMap.put("paging", pagingBoard);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "임대/임차 상세 조회")
    @GetMapping("/api/v1/admin/equip/detail/{idx}")
    public ResponseEntity<?> getEquipDetail(HttpServletRequest request,
                                          @Parameter(name = "idx", description = "equipIdx", in = ParameterIn.PATH)
                                          @PathVariable String idx) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == idx) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("idx", idx);
            Map<String, Object> result = equipService.selectEquipDetail(jwtMap);

            if(result == null || result.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", result);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "임대 수정")
    @PostMapping("/api/v1/admin/equip/update/rental")
    public ResponseEntity<?> updateRental(HttpServletRequest request, @Parameter(required = true) RentalDTO rentalDTO) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == rentalDTO) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("rentalDTO", rentalDTO);
            String path = "";
            if(rentalDTO.getConstructionImage() != null) {
                path = s3Util.uploadSingleFile(rentalDTO.getConstructionImage(), "equip/");
                log.info(path + "1");
            } else {
                path = rentalDTO.getOriginalFile();
            }
            jwtMap.put("equipImage", path);

            log.info(path + "2");

            int result = equipService.updateRental(jwtMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9991));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "임차 수정")
    @PostMapping("/api/v1/admin/equip/update/lease")
    public ResponseEntity<?> updateLease(
            HttpServletRequest request,
            @Schema(
                    description = "임차 데이터",
                    type = "array",
                    example = " {" +
                            "\"constructionIdx\" :\"1\"," +
                            "\"title\" :\"장비이름\"" +
                            "\"divideFirst\" :\"divideFirst\"" +
                            "\"divideSecond\" :\"연식(숫자만)\"" +
                            "\"location\" :\"시/구\"" +
                            "\"locationDetail\" :\"구/군\"" +
                            "\"periodStart\" :\"2022-04-11\"" +
                            "\"periodEnd\" :\"2022-04-11\"" +
                            "\"phone\" :\"010-1234-1234\"" +
                            "\"etc\" :\"기타사항\"" +
                            "}")
            @RequestBody Map<String, Object> paramMap) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == paramMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }


            int result = equipService.updateLease(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9991));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "장비 수정")
    @PostMapping("/api/v1/admin/equip/update")
    public ResponseEntity<?> updateEquip(
            HttpServletRequest request,
            @Schema(
                    description = "임차 데이터",
                    type = "array",
                    example = " {" +
                            "\"constructionIdx\" :\"1\"," +
                            "\"title\" :\"장비이름\"" +
                            "\"divideFirst\" :\"장비종류\"" +
                            "\"divideSecond\" :\"연식(숫자만)\"" +
                            "\"location\" :\"시/구\"" +
                            "\"locationDetail\" :\"구/군\"" +
                            "\"phone\" :\"010-1234-1234\"" +
                            "\"etc\" :\"기타사항\"" +
                            "}")
            @RequestBody Map<String, Object> paramMap) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == paramMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }


            int result = equipService.updateEquip(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9991));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "임대/임차 목록 검색")
    @GetMapping("/api/v1/admin/equip/search/{type}/{word}/{pageNo}")
    public ResponseEntity<?> getEquipLRList(HttpServletRequest request,
                                          @Parameter(name = "type", description = "임대 = 0, 임차 = 1", in = ParameterIn.PATH)
                                          @PathVariable String type,
                                          @Parameter(name = "word", description = "검색어", in = ParameterIn.PATH)
                                          @PathVariable String word,
                                          @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
                                          @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == type || Integer.parseInt(type) > 1 || Integer.parseInt(type) < 0 || null == pageNo || null == word) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            Map<String, Object> paramMap = new HashMap<>();

            paramMap.put("type", type);
            paramMap.put("word", word);
            paramMap.put("pageNo", pageNo);
            Paging pagingBoard = equipService.setEquipPaging(paramMap);
            List<Map> equipList = equipService.selectEquipList(paramMap);

            if(equipList == null || equipList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", equipList);
            rtnMap.put("paging", pagingBoard);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "장비 목록 검색")
    @GetMapping("/api/v1/admin/equip/search/{word}/{pageNo}")
    public ResponseEntity<?> getEquipList(HttpServletRequest request,
                                          @Parameter(name = "word", description = "검색어", in = ParameterIn.PATH)
                                          @PathVariable String word,
                                          @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
                                          @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == pageNo || null == word) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            Map<String, Object> paramMap = new HashMap<>();

            paramMap.put("word", word);
            paramMap.put("pageNo", pageNo);
            Paging pagingBoard = equipService.setEquipPaging(paramMap);
            List<Map> equipList = equipService.selectEquipList(paramMap);

            if(equipList == null || equipList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", equipList);
            rtnMap.put("paging", pagingBoard);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "임대/임차 삭제")
    @PostMapping("/api/v1/admin/equip/delete")
    public ResponseEntity<?> deleteCompany(
            @Schema(
                    description = "equipIdx",
                    type = "array",
                    example = " {\"idx\" :\"1, 2, 3, ...\"}")
            @RequestBody Map<String, Object> paramMap, HttpServletRequest request) {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            paramMap.put("list", makeForeach(paramMap.get("idx").toString()));

            int result = equipService.deleteEquip(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9990));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "장비주 목록 조회")
    @GetMapping("/api/v1/admin/owner/list/{pageNo}")
    public ResponseEntity<?> getOwnerList(HttpServletRequest request,
                                          @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
                                          @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == pageNo) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            Map<String, Object> paramMap = new HashMap<>();

            paramMap.put("pageNo", pageNo);
            Paging paging = equipService.setOwnerPaging(paramMap);
            List<Map> ownerList = equipService.selectOwnerList(paramMap);

            if(ownerList == null || ownerList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", ownerList);
            rtnMap.put("paging", paging);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "장비 목록 검색")
    @GetMapping("/api/v1/admin/owner/search/{word}/{pageNo}")
    public ResponseEntity<?> getOwnerSearchList(HttpServletRequest request,
                                          @Parameter(name = "word", description = "검색어", in = ParameterIn.PATH)
                                          @PathVariable String word,
                                          @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
                                          @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == pageNo || null == word) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            Map<String, Object> paramMap = new HashMap<>();

            paramMap.put("word", word);
            paramMap.put("pageNo", pageNo);
            Paging paging = equipService.setOwnerPaging(paramMap);
            List<Map> ownerList = equipService.selectOwnerList(paramMap);

            if(ownerList == null || ownerList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", ownerList);
            rtnMap.put("paging", paging);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "장비주 상세 조회")
    @GetMapping("/api/v1/admin/owner/detail/{idx}")
    public ResponseEntity<?> getOwnerDetail(HttpServletRequest request,
                                            @Parameter(name = "idx", description = "ownerIdx", in = ParameterIn.PATH)
                                            @PathVariable String idx) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == idx) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("idx", idx);
            Map<String, Object> result = equipService.selectOwnerDetail(jwtMap);

            if(result == null || result.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", result);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "장비주 수정")
    @PostMapping("/api/v1/admin/owner/update")
    public ResponseEntity<?> updateLabor(HttpServletRequest request, @Parameter(required = true) OwnerDTO ownerDTO) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (ownerDTO == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("ownerDTO", ownerDTO);
            String path = "";
            if(ownerDTO.getOwnerImage() != null) {
                path = s3Util.uploadSingleFile(ownerDTO.getOwnerImage(), "equipRegi/");
                log.info(path + "1");
            } else {
                path = ownerDTO.getOriginalFile();
            }
            jwtMap.put("ownerImage", path);

            log.info(path + "2");

            int result = equipService.updateOwner(jwtMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9991));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

}
