package kr.co.dk.sample.api.app.job.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class JobDAO {

    private static final Logger log = LogManager.getLogger(JobDAO.class);
    static final String NAMESAPCE =  "kr.co.dk.sample.api.app.job.mapper.JobDAO.";

    //	@Autowired
    private SqlSession sqlSession;

    //	@Qualifier("readOnlySqlSession")
    private SqlSessionTemplate readOnlySqlSession;

    public JobDAO(SqlSession sqlSession,SqlSessionTemplate readOnlySqlSession){
        this.sqlSession = sqlSession;
        this.readOnlySqlSession = readOnlySqlSession;
    }

    @Autowired
    Environment env;

    public Map<String, Object> selectJobCnt(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectJobCnt:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectJobCnt", map);

        return result;
    }

    public List<Map> selectJobList(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectJobList:::");
        List<Map> result = readOnlySqlSession.selectList(NAMESAPCE + "selectJobList", map);

        return result;
    }

    public Map<String, Object> selectJobDetail(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectJobDetail:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectJobDetail", map);

        return result;
    }

    public int updateJobOffer(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateJobOffer:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateJobOffer", map);

        return result;
    }

    public int updateJobSearch(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateJobSearch:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateJobSearch", map);

        return result;
    }

    public int deleteJob(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ deleteJob:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "deleteJob", map);

        return result;
    }

    public int allowJob(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ allowJob:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "allowJob", map);

        return result;
    }
}
