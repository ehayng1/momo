package kr.co.dk.sample.api.app.banner.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.co.dk.sample.api.app.banner.dto.BannerDTO;
import kr.co.dk.sample.api.app.banner.service.BannerService;
import kr.co.dk.sample.api.app.labor.dto.LaborDTO;
import kr.co.dk.sample.api.common.model.ApiResponse;
import kr.co.dk.sample.api.common.model.ErrorCode;
import kr.co.dk.sample.api.common.model.Paging;
import kr.co.dk.sample.api.common.util.S3Util;
import kr.co.dk.sample.api.config.security.JwtTokenProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static kr.co.dk.sample.api.common.util.CommonUtil.makeForeach;

@Tag(name = "배너")
@RestController
public class BannerController {
    private static final Logger log = LogManager.getLogger(BannerController.class);

    @Autowired
    BannerService bannerService;

    @Autowired
    JwtTokenProvider jwtTokenProvider;

    @Autowired
    S3Util s3Util;

    @Operation(summary = "배너 목록", description = "")
    @GetMapping("/api/v1/admin/banner/list/{pageNo}")
    public ResponseEntity<?> selectAllBoard(HttpServletRequest request,
                                            @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
                                            @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (pageNo == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("pageNo", pageNo);

            Paging paging = bannerService.setBannerPaging(jwtMap);
            List<Map> bannerList = bannerService.selectAllBanner(jwtMap);

            if (bannerList == null || bannerList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", bannerList);
            rtnMap.put("paging", paging);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "배너 추가", description = "")
    @PostMapping("/api/v1/admin/banner/insertBanner")
    public ResponseEntity<?> insertPostBanner(HttpServletRequest request, @Parameter(required = true) BannerDTO bannerDTO
    ) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }


            jwtMap.put("bannerDTO", bannerDTO);
            String path = "";
            if (bannerDTO.getBannerImage() != null) {
                path = s3Util.uploadSingleFile(bannerDTO.getBannerImage(), "banner/");
                log.info(path + "1");
            } else {
                path = bannerDTO.getOriginalFile();
            }
            jwtMap.put("path", path);

            log.info(path + "배너추가 url");
            jwtMap.put("result", bannerDTO);


            int result = bannerService.insertBanner(jwtMap);
            if (result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9989));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "배너 삭제", description = "")
    @PostMapping("/api/v1/admin/banner/delete")
    public ResponseEntity<?> deleteBanner(@Schema(
            description = "issueIdx",
            type = "array",
            example = " {\"idx\" :\"1, 2, 3, ...\"}")
                                          @RequestBody Map<String, Object> paramMap, HttpServletRequest request) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            paramMap.put("list", makeForeach(paramMap.get("idx").toString()));

            int result = bannerService.deleteBanner(paramMap);

            if (result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9990));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "배너 상세 조회")
    @GetMapping("/api/v1/admin/banner/detail/{idx}")
    public ResponseEntity<?> selectBoardDetail(HttpServletRequest request,
                                               @Parameter(name = "idx", description = "배너 번호", in = ParameterIn.PATH)
                                               @PathVariable String idx) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (idx == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put("bannerIdx", idx.toString());

            Map<String, Object> detail = bannerService.selectBannerDetail(paramMap);

            if (detail == null || detail.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", detail);

            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "배너 수정")
    @PostMapping("/api/v1/admin/banner/update")
    public ResponseEntity<?> updateBanner(HttpServletRequest request, @Parameter(required = true) BannerDTO bannerDTO) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (bannerDTO == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("bannerDTO", bannerDTO);
            String path = "";
            if (bannerDTO.getBannerImage() != null) {
                path = s3Util.uploadSingleFile(bannerDTO.getBannerImage(), "banner/");
                log.info(path + "1");
            } else {
                path = bannerDTO.getOriginalFile();
            }
            jwtMap.put("path", path);

            log.info(path + "2");

            int result = bannerService.updateBanner(jwtMap);

            if (result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9991));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }
}
