package kr.co.dk.sample.api.common.push.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import kr.co.dk.sample.api.common.model.enums.type.LinkType;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class Push {


    private long idx;

//    private User to;
    private String title;
    private String body;
    private LinkType linkType;
    private String targetIdx;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime toBeSentAt;

    boolean sent = false;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime sentAt;
}