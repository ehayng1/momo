package kr.co.dk.sample.api.app.company.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class CompanyDTO {
    private int company_idx;
    private MultipartFile company_logo;
    private String company_name;
    private String company_address;
    private String company_address_detail;
    private String original_logo; // 수정에서만 쓰임
}
