package kr.co.dk.sample.api.app.job.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class OfferDTO {
    private int workIdx;
    private String constructor;
    private String workTitle;
    private MultipartFile jobImage;
    private String divideFirst;
    private String siteAddress;
    private String periodStart;
    private String periodEnd;
    private String phone;
    private String payment;
    private String rest;
    private String etc;
    private String originalFile; // 구인 수정용
}
