package kr.co.dk.sample.api.app.banner.dao;

import kr.co.dk.sample.api.app.board.dao.BoardDAO;
import org.apache.ibatis.session.SqlSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class BannerDAO {
    private static final Logger log = LogManager.getLogger(BannerDAO.class);
    static final String NAMESAPCE = "kr.co.dk.sample.api.app.banner.mapper.BannerDAO.";

    //	@Autowired
    private SqlSession sqlSession;

    //	@Qualifier("readOnlySqlSession")
    private SqlSessionTemplate readOnlySqlSession;

    public BannerDAO(SqlSession sqlSession, SqlSessionTemplate readOnlySqlSession) {
        this.sqlSession = sqlSession;
        this.readOnlySqlSession = readOnlySqlSession;
    }

    @Autowired
    Environment env;


    public Map<String, Object> selectBannerCnt(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectBannerCnt:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectBannerCnt", map);

        return result;
    }

    public List<Map> selectAllBanner(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectAllBanner:::");
        List<Map> banner = readOnlySqlSession.selectList(NAMESAPCE + "selectAllBanner", map);

        return banner;
    }

    public Map<String, Object> selectBannerDetail(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectBannerDetail:::");
        Map<String, Object> banner = readOnlySqlSession.selectOne(NAMESAPCE + "selectBannerDetail", map);

        return banner;
    }

    public int updateBanner(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateBanner:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateBanner", map);

        return result;
    }

    public int insertBanner(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateBanner:::");
        int result = readOnlySqlSession.insert(NAMESAPCE + "insertBanner", map);

        return result;
    }

    public int deleteBanner(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ deleteBanner:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "deleteBanner", map);

        return result;
    }
}
