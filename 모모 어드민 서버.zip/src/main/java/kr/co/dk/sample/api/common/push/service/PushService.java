package kr.co.dk.sample.api.common.push.service;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
public class PushService {
    private static final Logger log = LogManager.getLogger(PushService.class);


//    public boolean sendMessage(Push push){
//        HashMap<String ,String> data = new HashMap<String, String>();
//        data.put("type", push.getLinkType() == null? LinkType.ALARM.name():push.getLinkType().name());
//        data.put("idx", push.getTargetIdx() == null?"0":push.getTargetIdx());
//        return sendMessage(push.getTo().getFcmToken(), push.getTitle(), push.getBody(), data);
//    }

//    public boolean sendMessage(String token, String title, String body, HashMap<String, String> data){
//        try {
//            Notification notification= Notification.builder().setTitle(title).setBody(body).build();
//            Message message = Message.builder().setToken(token).putAllData(data)
//                    .setNotification(notification).build();
//            String result = FirebaseMessaging.getInstance().send(message);
//        } catch (FirebaseMessagingException e) {
//            log.error("FirebaseMessagingException : {}", e);
//        } catch (Exception e){
//            log.error("Exception : {}", e);
//        }
//
//        return true;
//    }
}
