package kr.co.dk.sample.api.app.user.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class UserDAO {

    private static final Logger log = LogManager.getLogger(UserDAO.class);
    static final String NAMESAPCE="kr.co.dk.sample.api.app.user.mapper.UserDAO.";

    //	@Autowired
    private SqlSession sqlSession;

    //	@Qualifier("readOnlySqlSession")
    private SqlSessionTemplate readOnlySqlSession;

    public UserDAO(SqlSession sqlSession,SqlSessionTemplate readOnlySqlSession){
        this.sqlSession = sqlSession;
        this.readOnlySqlSession = readOnlySqlSession;
    }

    @Autowired
    Environment env;

    public Map<String, Object> selectUserCnt(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectUserCnt:::");
        Map<String,Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectUserCnt", map);

        return result;
    }


    public List<Map> selectUserList(Map<String, Object> map) throws Exception{
        log.debug("+++++++++++++++++++++++++++++++++++++ selectUserList:::");
        List<Map> user = readOnlySqlSession.selectList(NAMESAPCE + "selectUserList", map);

        return user;
    }

    public Map<String, Object> selectUserInfo(Map<String, Object> map) throws Exception{
        log.debug("+++++++++++++++++++++++++++++++++++++ selectMemberInfo:::");
        Map<String,Object> user = readOnlySqlSession.selectOne(NAMESAPCE + "selectUserInfo", map);

        return user;
    }

    public int updateUser(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateUser:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateUser", map);

        return result;
    }


}
