package kr.co.dk.sample.api.app.labor.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class LaborDAO {

    private static final Logger log = LogManager.getLogger(LaborDAO.class);
    static final String NAMESAPCE =  "kr.co.dk.sample.api.app.labor.mapper.LaborDAO.";

    //	@Autowired
    private SqlSession sqlSession;

    //	@Qualifier("readOnlySqlSession")
    private SqlSessionTemplate readOnlySqlSession;

    public LaborDAO(SqlSession sqlSession,SqlSessionTemplate readOnlySqlSession){
        this.sqlSession = sqlSession;
        this.readOnlySqlSession = readOnlySqlSession;
    }

    @Autowired
    Environment env;

    public Map<String, Object> selectLaborCnt(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectLaborCnt:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectLaborCnt", map);

        return result;
    }

    public Map<String, Object> selectTypeCnt(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectTypeCnt:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectTypeCnt", map);

        return result;
    }

    public List<Map> selectLaborList(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectLaborList:::");
        List<Map> laborList = readOnlySqlSession.selectList(NAMESAPCE + "selectLaborList", map);
        return laborList;
    }

    public Map<String, Object> selectLaborDetail(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectLaborDetail:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectLaborDetail", map);

        return result;
    }

    public int insertLabor(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ insertLabor:::");
        int result = readOnlySqlSession.insert(NAMESAPCE + "insertLabor", map);

        return result;
    }

    public int updateLabor(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateLabor:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateLabor", map);

        return result;
    }

    public int deleteLabor(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ deleteLabor:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "deleteLabor", map);

        return result;
    }

    public List<Map> getAllTypeList() throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ getAllTypeList:::");
        List<Map> laborList = readOnlySqlSession.selectList(NAMESAPCE + "getAllTypeList");
        return laborList;
    }

    public List<Map> getTypeList(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ getTypeList:::");
        List<Map> laborList = readOnlySqlSession.selectList(NAMESAPCE + "getTypeList", map);
        return laborList;
    }

    public int addType(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ addType:::");
        int result = readOnlySqlSession.insert(NAMESAPCE + "addType", map);

        return result;
    }

    public int updateType(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateType:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateType", map);

        return result;
    }
}
