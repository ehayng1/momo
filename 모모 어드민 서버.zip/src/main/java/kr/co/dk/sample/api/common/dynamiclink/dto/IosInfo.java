package kr.co.dk.sample.api.common.dynamiclink.dto;

import lombok.Data;

@Data
public class IosInfo {
    private String iosBundleId;
}
