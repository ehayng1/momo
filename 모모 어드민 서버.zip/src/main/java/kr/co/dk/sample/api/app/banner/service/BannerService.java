package kr.co.dk.sample.api.app.banner.service;

import kr.co.dk.sample.api.app.banner.dao.BannerDAO;
import kr.co.dk.sample.api.common.model.Paging;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Properties;

@Service
public class BannerService {
    private static final Logger log = LogManager.getLogger(BannerService.class);

    @Autowired
    BannerDAO bannerDAO;

    @Qualifier("prop")
    private Properties properties;

    @Autowired
    Environment env;

    public Paging setBannerPaging(Map<String, Object> paramMap) throws Exception {
        Map<String, Object> map = bannerDAO.selectBannerCnt(paramMap);
        int totalCount = ((Long) map.get("cnt")).intValue();
        int pageNo = 1;
        int pageSize = 10;

        Paging paging = new Paging();

        try {

            if (paramMap.get("page_size") != null) {
                String sPageSize = (String) paramMap.get("page_size");
                try {
                    pageSize = Integer.parseInt(sPageSize);
                } catch (Exception e) {
                }
            }

            if (paramMap.get("pageNo") != null) {
                String sPageNo = (String) paramMap.get("pageNo");
                try {
                    pageNo = Integer.parseInt(sPageNo);
                } catch (Exception e) {
                }
            }

            paging.setPageNo(pageNo);
            paging.setPageSize(pageSize);
            paging.setTotalCount(totalCount);
        } catch (Exception e) {
            throw e;
        }

        paramMap.put("start_idx", paging.getStartIndex());
        paramMap.put("page_size", paging.getPageSize());

        return paging;
    }

    public List<Map> selectAllBanner(Map<String, Object> map) throws Exception {
        return bannerDAO.selectAllBanner(map);
    }

    public Map<String, Object> selectBannerDetail(Map<String, Object> map) throws Exception {
        return bannerDAO.selectBannerDetail(map);
    }

    public int updateBanner(Map<String, Object> map) throws Exception {
        return bannerDAO.updateBanner(map);
    }
    public int deleteBanner(Map<String, Object> map) throws Exception {
        return bannerDAO.deleteBanner(map);
    }
    public int insertBanner(Map<String, Object> map) throws Exception {
        return bannerDAO.insertBanner(map);
    }
}
