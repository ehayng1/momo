package kr.co.dk.sample.api.app.company.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class SiteDTO {
    private int company_idx;
    private int site_idx;
    private String site_name;
    private String site_address;
    private String site_period_start;
    private String site_period_end;
    private MultipartFile site_picture;
    private String original_file; // 수정에서만 쓰임
}
