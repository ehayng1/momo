package kr.co.dk.sample.api.app.labor.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class LaborDTO {
    private int laborIdx;
    private String laborName;
    private String laborSimple;
    private String laborDescription;
    private String laborType;
    private String laborCareer;
    private String laborPhone;
    private String laborAddress;
    private MultipartFile laborImage;
    private String originalFile; // 수정 시 사용
}
