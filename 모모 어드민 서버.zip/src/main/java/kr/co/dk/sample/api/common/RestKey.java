package kr.co.dk.sample.api.common;

public interface RestKey {

	/**
	 * S3
	 */
	static public String RESION_NAME = "ap-northeast-2";
	static public String ADMIN_ACCESS_KEY = "AKIA2U5GLA257EJQ455Q";
	static public String ADMIN_SECRET_KEY = "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";
	static public int SIGNED_URL_EXPIRED_TIME = 1000 * 60;



	public static final String NAME_USER_ID = "user_id";
	public static final String NAME_USER_PW = "user_pw";
	public static final String NAME_PAGE = "page";

	public static final String NAME_SESSION_USER_IDX = "idx";
	public static final String NAME_SESSION_USER_NAME = "user_name";

	public static final String NAME_USER_IDX 			= "user_idx";
	public static final String NAME_OFFSET 				= "offset";
	public static final String NAME_COUNT 				= "count";
	public static final String NAME_STATUS 				= "status";
	public static final String NAME_CONTRACT_NAME 		= "c_name";
	public static final String NAME_CONTRACT_TO_USER 	= "to_user";
	public static final String NAME_CONTRACT_FROM_USER 	= "from_user";
	public static final String NAME_CONTRACT_PRICE 		= "c_price";
	public static final String NAME_CONTRACT_DATE_RANGE = "c_date_range";
	public static final String NAME_CONTRACT_CONTENT 	= "c_content";
	public static final String NAME_CONTRACT_FILE 		= "c_file";
	public static final String NAME_CONTRACT_TXID 		= "txid";
	public static final String NAME_CONTRACT_START_DATE	= "start_date";
	public static final String NAME_CONTRACT_END_DATE 	= "end_date";
	public static final String NAME_CONTRACT_REG_DATE 	= "reg_date";
	public static final String NAME_CONTRACT_ACT_TXID 	= "act_txid";
	public static final String NAME_CONTRACT_USER_ROLE 	= "user_role";
	public static final String NAME_CONTRACT_IDX 		= "c_idx";
	public static final String NAME_CONTRACT_IS_READ 	= "is_read";

	public static final int PAGE_ROWS	= 10;

	public static final String RESULT_LIST = "list";
	public static final String RESULT_TOTAL_CNT = "total_cnt";
	public static final String RESULT_UNREAD_CNT = "unread_cnt";
	public static final String RESULT_FILE_URL = "file_url";

	public static final String CONTRACT_USER_INFO = "users";
	public static final String TO_USER_INFO = "to_user_info";
	public static final String FROM_USER_INFO = "from_user_info";
	public static final String CONTRACT_DOC_HASH = "contract_doc_hash";
	public static final String ACT_USER = "act_user";
	public static final String ACT_TYPE = "act_type";
	public static final String ACT_TYPE_REGIEST 	= "REG";
	public static final String ACT_TYPE_REJECT 		= "REJ";
	public static final String ACT_TYPE_CONFIRM 	= "CON";

	public static final String RES_ORIGIN_HASH 		= "origin_hash";
	public static final String RES_CHECK_HASH 		= "check_hash";


	public static final int TYPE_GAB 	= 2;
	public static final int TYPE_UEL 	= 3;

}
