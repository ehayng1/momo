package kr.co.dk.sample.api.common.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Arrays;

@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum ErrorCode {

    CODE_0000(0000, "success"),
    CODE_500(500, "internal error")
    /*공통 에러 */
    ,CODE_9001(9001, "정렬 할 수 있는 컬럼이 아닙니다.")
    ,CODE_9002(9002, "파라미터 null 오류")

    /** 처리결과 코드 */
    ,CODE_9999(9999, "[9999] 오류. 고객센터에 문의 바랍니다.")
    ,CODE_9998(9998, "[9998] 필수값이 없습니다.")
    ,CODE_9997(9997, "[9997] 로그인이 필요합니다.")
    ,CODE_9996(9996, "[9996] 이미 로그인 하셨습니다.")
    ,CODE_9995(9995, "[9995] 출금계좌가 등록되지 않았습니다. 내정보 인증센터에서 계좌등록을 해주십시오.")
    ,CODE_9994(9994, "[9994] 2차 로그인이 필요합니다.")
    ,CODE_9993(9993, "[9993] 필수값 확인이 필요합니다.")
    ,CODE_9992(9992, "[9992] SMS 발송 실패.")
    ,CODE_9991(9991, "수정 실패")
    ,CODE_9990(9990, "삭제 실패")
    ,CODE_9989(9989, "등록 실패")
    ,CODE_9988(9988, "조회 실패")
    ,CODE_2000(2000, "[2000] 이메일 인증이 완료되었습니다.")

    /* token, login*/
    ,CODE_1101(1101, "토큰이 만료 되었습니다.")
    ,CODE_1103(1103, "토큰 변환 오류")
    ,CODE_1104(1104, "jwt 토큰이 없습니다.")
    ,CODE_1105(1105, "리프레시 토큰이 아닙니다.")
    ,CODE_1106(1106, "회원 정보를 찾을 수 없습니다.")
    ,CODE_1107(1107, "액세스 토큰이 아닙니다.")
    ,CODE_1108(1108, "회원정보를 찾을 수 없습니다.")
    ,CODE_1109(1109, "로그인 할수 없는 유저입니다.")
    ,CODE_1110(1110, "인증서버 통신 에러")
    ,CODE_1111(1111, "카카오 restapi 통신 에러")
    ,CODE_1116(1116, "어드민 권한이 없습니다.")
    ,CODE_1117(1117, "탈퇴 요청 중인 상태입니다.")
    ,CODE_1118(1118, "로그인 할수 없는 상태입니다")
    ,CODE_1119(1119, "잘못된 로그인 정보입니다.")
    ,CODE_1120(1120, "비밀번호가 틀립니다.")

    /*  유저 동작 에러*/
    ,CODE_1208(1208, "이미 푸시 알람이 켜져 있습니다.")
    ,CODE_1209(1209, "이미 푸시 알람이 꺼져 있습니다.")
    ,CODE_1210(1210, "해당기간 회원데이터가 없습니다.")

    /* file */
    ,CODE_1501(1501, "파일을 저장을 할수 없습니다.")
    ,CODE_1502(1502, "썸네일을 저장 할 수 없습니다.")
    ,CODE_1503(1503, "업로드 용량 제한을 초과 하였습니다.")
    ,CODE_1504(1504, "엑셀파일이 아닙니다.")

    /* 건설사 관련 */
    ,CODE_2101(2101, "등록된 건설사가 없습니다.")
    ,CODE_2102(2102, "등록된 현장이 없습니다.")
    ,CODE_2103(2103, "조회되는 건설사가 없습니다.")
    ,CODE_2104(2104, "평가 등록 실패")

    /* 게시글 관련 */
    ,CODE_2121(2121, "조회되는 게시글이 없습니다.")
    ,CODE_2122(2122, "게시글 삭제 실패")
    ,CODE_2123(2123, "게시글 등록 실패")
    ,CODE_2124(2124, "댓글 등록 실패")

    /* 검색 */
    ,CODE_3101(3101, "검색 결과가 없습니다.")



    /** 어드민 승인 관련*/

    ,CODE_2107(2107, "해당 유저가 존재하지 않습니다.")
    ,CODE_2110( 2110, "해당 게시물이 존재 하지 않습니다..")
    ,CODE_2111(2111, "탈퇴 처리가 불가능한 유저입니다.")
    ,CODE_2112(2112, "유저가 존재하지 않습니다.")
    ;
    private Integer code;
    private String msg;

    ErrorCode(Integer code, String msg){
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode(){
        return code;
    }
    public String getMsg(){
        return msg;
    }

    public static ErrorCode getErrorCodeByCode(Integer code) {
        return Arrays.stream(ErrorCode.values()).filter(x -> x.getCode().equals(code)).findFirst().get();
    }
}
