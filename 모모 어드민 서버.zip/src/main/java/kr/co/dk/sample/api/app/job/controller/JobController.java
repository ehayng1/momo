package kr.co.dk.sample.api.app.job.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.co.dk.sample.api.app.board.controller.BoardController;
import kr.co.dk.sample.api.app.job.dto.OfferDTO;
import kr.co.dk.sample.api.app.job.dto.SearchDTO;
import kr.co.dk.sample.api.app.job.service.JobService;
import kr.co.dk.sample.api.common.model.ApiResponse;
import kr.co.dk.sample.api.common.model.ErrorCode;
import kr.co.dk.sample.api.common.model.Paging;
import kr.co.dk.sample.api.common.util.S3Util;
import kr.co.dk.sample.api.config.security.JwtTokenProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static kr.co.dk.sample.api.common.util.CommonUtil.makeForeach;

@Tag(name="인력(구인/구직)")
@RestController
public class JobController {

    private static final Logger log = LogManager.getLogger(BoardController.class);

    @Autowired
    JobService jobService;

    @Autowired
    JwtTokenProvider jwtTokenProvider;

    @Autowired
    S3Util s3Util;

    @Operation(summary = "구인/구직 목록 조회")
    @GetMapping("/api/v1/admin/job/list/{type}/{pageNo}")
    public ResponseEntity<?> getJobList(
            HttpServletRequest request,
            @Parameter(name = "type", description = "구인 = 0, 구직 = 1", in = ParameterIn.PATH)
            @PathVariable String type,
            @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
            @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == type || Integer.parseInt(type) > 1 || Integer.parseInt(type) < 0 || null == pageNo) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("pageNo", pageNo);
            jwtMap.put("type", type);
            Paging pagingBoard = jobService.setJobPaging(jwtMap);
            List<Map> jobList = jobService.selectJobList(jwtMap);

            if(jobList == null || jobList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", jobList);
            rtnMap.put("paging", pagingBoard);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "구인/구직 목록 검색")
    @GetMapping("/api/v1/admin/job/search/{type}/{word}/{pageNo}")
    public ResponseEntity<?> getJobSearchList(
            HttpServletRequest request,
            @Parameter(name = "type", description = "구인 = 0, 구직 = 1", in = ParameterIn.PATH)
            @PathVariable String type,
            @Parameter(name = "word", description = "검색어", in = ParameterIn.PATH)
            @PathVariable String word,
            @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
            @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == type || Integer.parseInt(type) > 1 || Integer.parseInt(type) < 0 || null == pageNo || null == word) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("pageNo", pageNo);
            jwtMap.put("word", word);
            jwtMap.put("type", type);
            Paging pagingBoard = jobService.setJobPaging(jwtMap);
            List<Map> jobList = jobService.selectJobList(jwtMap);

            if(jobList == null || jobList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", jobList);
            rtnMap.put("paging", pagingBoard);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "구인/구직 상세조회")
    @GetMapping("/api/v1/admin/job/detail/{idx}")
    public ResponseEntity<?> getJobSearchList(
            HttpServletRequest request,
            @Parameter(name = "idx", description = "workIdx", in = ParameterIn.PATH)
            @PathVariable String idx) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == idx) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("workIdx", idx);

            Map<String, Object> result = jobService.selectJobDetail(jwtMap);

            if(result == null || result.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", result);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "구직 수정")
    @PostMapping("/api/v1/admin/job/update/search")
    public ResponseEntity<?> updateJobSearch(
            HttpServletRequest request,
            @Schema(
                    description = "workIdx",
                    type = "array",
                    example = " {" +
                            "\"workIdx\" :\"1\"," +
                            "\"name\" :\"하이데브\"" +
                            "\"phone\" :\"010-1234-1234\"" +
                            "\"divideFirst\" :\"직종:개인/팀여부[:안전교육이수]\"" +
                            "\"divideSecond\" :\"직종상세\"" +
                            "\"startDate\" :\"2022-04-04\"" +
                            "\"endDate\" :\"2022-04-11\"" +
                            "\"etc\" :\"기타사항\"" +
                            "}")
            @RequestBody Map<String, Object> paramMap) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            int result = jobService.updateJobSearch(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9991));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "구인 수정")
    @PostMapping("/api/v1/admin/job/update/offer")
    public ResponseEntity<?> updateJobOffer(HttpServletRequest request, @Parameter(required = true) OfferDTO offerDTO) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (offerDTO == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("offerDTO", offerDTO);
            String path = "";
            if(offerDTO.getJobImage() != null) {
                path = s3Util.uploadSingleFile(offerDTO.getJobImage(), "job/");
                log.info(path + "1");
            } else {
                path = offerDTO.getOriginalFile();
            }
            jwtMap.put("workPicture", path);

            log.info(path + "2");

            int result = jobService.updateJobOffer(jwtMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9991));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "구인/구직 삭제")
    @PostMapping("/api/v1/admin/job/delete")
    public ResponseEntity<?> deleteJob(
            HttpServletRequest request,
            @Schema(
                    description = "workIdx",
                    type = "array",
                    example = " {" +
                                    "\"idx\" :\"1\"" +
                                "}")
            @RequestBody Map<String, Object> paramMap) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            paramMap.put("list", makeForeach(paramMap.get("idx").toString()));

            int result = jobService.deleteJob(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9990));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "구인 허가")
    @PostMapping("/api/v1/admin/job/allow")
    public ResponseEntity<?> allowJob(
            HttpServletRequest request,
            @Schema(
                    description = "workIdx",
                    type = "array",
                    example = " {" +
                                    "\"idx\" :\"1\"" +
                                "}")
            @RequestBody Map<String, Object> paramMap) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            paramMap.put("list", makeForeach(paramMap.get("idx").toString()));

            int result = jobService.allowJob(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9990));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

}
