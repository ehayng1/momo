package kr.co.dk.sample.api.app.user.service;

import kr.co.dk.sample.api.app.user.dao.UserDAO;
import kr.co.dk.sample.api.common.model.Paging;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Properties;


@Service
public class UserService {
    private static final Logger log = LogManager.getLogger(UserService.class);

//    public UserService(UserMapper userRepository){
//        this.userRepository = userRepository;
//
//    }
//
//    private UserMapper userRepository;

    @Autowired
    UserDAO userDAO;

    @Qualifier("prop")
    private Properties properties;

    @Autowired
    Environment env;

    public Paging setUserPaging(Map<String, Object> paramMap) throws Exception {
        Map<String, Object> map = userDAO.selectUserCnt(paramMap);
        int totalCount = ((Long) map.get("cnt")).intValue();
        int pageNo = 1;
        int pageSize = 10;

        Paging paging = new Paging();

        try {

            if (paramMap.get("page_size") != null) {
                String sPageSize = (String) paramMap.get("page_size");
                try {
                    pageSize = Integer.parseInt(sPageSize);
                }catch (Exception e) {}
            }

            if (paramMap.get("pageNo") != null) {
                String sPageNo = (String) paramMap.get("pageNo");
                try {
                    pageNo = Integer.parseInt(sPageNo);
                }catch (Exception e) {}
            }

            paging.setPageNo(pageNo);
            paging.setPageSize(pageSize);
            paging.setTotalCount(totalCount);
        } catch (Exception e) {
            throw e;
        }

        paramMap.put("start_idx", paging.getStartIndex());
        paramMap.put("page_size", paging.getPageSize());

        return paging;
    }


    public List<Map> selectUserList(Map<String, Object> map) throws Exception {
        return userDAO.selectUserList(map);
    }

    public Map<String, Object> selectUserInfo(Map<String, Object> map) throws Exception {
        return userDAO.selectUserInfo(map);
    }

    public int updateUser(Map<String, Object> map) throws Exception {
        return userDAO.updateUser(map);
    }





//    legacy logic
//
//    public UserDetail getUserDetail(long userIdx){
//        User user = userRepository.findByIdx(userIdx);
//        UserDetail userDetail = new UserDetail();
//        return userDetail;
//    }
//
//    @Transactional
//    public void updateUserDetail(UserDetail userDetail, long userIdx){
//        User user = userRepository.findByIdx(userIdx);
//        user.setName(userDetail.getName());
////        user.setPhoneNumber(userDetail.getPhoneNumber());
////        user.setEmail(userDetail.getEmail());
////        user.setZipCode(userDetail.getZipCode());
////        user.setAddressLocation(userDetail.getAddressLocation());
////        user.setAddressDetail(userDetail.getAddressDetail());
////        user.setBirthday(userDetail.getBirthday());
////        user.setBirthYear(userDetail.getBirthYear());
////        userRepository.save(user);
//    }
//
//    @Transactional
//    public void leaveRequest(long userIdx){
//        User user = userRepository.findByIdx(userIdx);
//        user.setStatus(UserStatus.LEAVE_REQUEST);
////        userRepository.save(user);
//    }

}
