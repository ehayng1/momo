package kr.co.dk.sample.api.app.terms.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.co.dk.sample.api.app.terms.service.TermsService;
import kr.co.dk.sample.api.common.model.ApiResponse;
import kr.co.dk.sample.api.common.model.ErrorCode;
import kr.co.dk.sample.api.common.model.Paging;
import kr.co.dk.sample.api.config.security.JwtTokenProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static kr.co.dk.sample.api.common.util.CommonUtil.makeForeach;

@Tag(name="약관")
@RestController
public class TermsController {

    private static final Logger log = LogManager.getLogger(TermsController.class);

    @Autowired
    TermsService termsService;

    @Autowired
    JwtTokenProvider jwtTokenProvider;


    @Operation(summary = "약관 목록")
    @GetMapping(path="/api/v1/admin/terms/list/{pageNo}")
    public ResponseEntity<?> getTypeList(HttpServletRequest request,
                                         @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
                                         @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (pageNo == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("pageNo", pageNo);

            Paging paging = termsService.setTermsPaging(jwtMap);
            List<Map> result = termsService.getTermsList(jwtMap);

            rtnMap.put("result", result);
            rtnMap.put("paging", paging);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }


    @Operation(summary = "약관 내용 가져오기", description = "")
    @GetMapping(path="/api/v1/admin/terms/detail/{idx}")
    public ResponseEntity<?> getTermsDetail(HttpServletRequest request, @PathVariable(name = "idx") String idx) throws Exception {
        log.info("=============================START========================================== in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            if (idx == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put("idx", idx);

            Map<String, Object> result = termsService.getTermsDetail(paramMap);

            if (result == null || result.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9988));
            }

            rtnMap.put("result", result);

            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }


    @Operation(summary = "약관 수정")
    @PostMapping(path="/api/v1/admin/terms/update")
    public ResponseEntity<?> updateType(@Schema(
            description = "idx, title, content(HTML text)",
            type = "array",
            example = " {" +
                    "\"idx\" :\"1\"" +
                    "\"title\" :\"약관제목\"" +
                    "\"content\" :\"<br>안녕하세요</br>\"" +
                    "}")
            @RequestBody Map<String, Object> paramMap, HttpServletRequest request) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            int result = termsService.updateTerms(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9990));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

}
