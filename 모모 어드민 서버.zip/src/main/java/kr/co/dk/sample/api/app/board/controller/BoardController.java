package kr.co.dk.sample.api.app.board.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.co.dk.sample.api.app.board.dto.BoardDTO;
import kr.co.dk.sample.api.app.board.dto.ReplyDTO;
import kr.co.dk.sample.api.app.board.service.BoardService;
import kr.co.dk.sample.api.common.model.ApiResponse;
import kr.co.dk.sample.api.common.model.ErrorCode;
import kr.co.dk.sample.api.common.model.Paging;
import kr.co.dk.sample.api.common.util.S3Util;
import kr.co.dk.sample.api.config.security.JwtTokenProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static kr.co.dk.sample.api.common.util.CommonUtil.makeForeach;

@Tag(name="이슈 (게시글)")
@RestController
public class BoardController {

    private static final Logger log = LogManager.getLogger(BoardController.class);

    @Autowired
    BoardService boardService;

    @Autowired
    JwtTokenProvider jwtTokenProvider;

    @Autowired
    S3Util s3Util;

    @Operation(summary = "이슈 목록", description = "")
    @GetMapping("/api/v1/admin/board/list/{pageNo}")
    public ResponseEntity<?> selectAllBoard(HttpServletRequest request,
            @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
            @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if(pageNo == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("pageNo", pageNo);

            Paging pagingBoard = boardService.setBoardPaging(jwtMap);
            List<Map> boardList = boardService.selectAllBoard(jwtMap);

            if(boardList == null || boardList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", boardList);
            rtnMap.put("paging", pagingBoard);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "이슈 검색", description = "")
    @GetMapping("/api/v1/admin/board/search/{word}/{pageNo}")
    public ResponseEntity<?> searchAllBoard(HttpServletRequest request,
            @Parameter(name = "word", description = "검색어", in = ParameterIn.PATH)
            @PathVariable String word,
            @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
            @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if(pageNo == null || word == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("pageNo", pageNo);
            jwtMap.put("word", word);

            Paging pagingBoard = boardService.setBoardPaging(jwtMap);
            List<Map> boardList = boardService.selectAllBoard(jwtMap);

            if(boardList == null || boardList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", boardList);
            rtnMap.put("paging", pagingBoard);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "게시글 상태전환 (삭제처리)")
    @PostMapping("/api/v1/admin/board/delete")
    public ResponseEntity<?> deleteBoard(
            @Schema(
                    description = "issueIdx",
                    type = "array",
                    example = " {\"idx\" :\"1, 2, 3, ...\"}")
            @RequestBody Map<String, Object> paramMap, HttpServletRequest request) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            paramMap.put("list", makeForeach(paramMap.get("idx").toString()));

            int result = boardService.deleteBoard(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9990));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "댓글 상태전환 (삭제처리)")
    @PostMapping("/api/v1/admin/reply/delete")
    public ResponseEntity<?> deleteReply(
            @Schema(
                    description = "replyIdx",
                    type = "array",
                    example = " {\"idx\" :\"1, 2, 3, ...\"}")
            @RequestBody Map<String, Object> paramMap, HttpServletRequest request) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            paramMap.put("list", makeForeach(paramMap.get("idx").toString()));

            int result = boardService.deleteReply(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9990));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "게시글 상세 조회")
    @GetMapping("/api/v1/admin/board/detail/{idx}")
    public ResponseEntity<?> selectBoardDetail(HttpServletRequest request,
           @Parameter(name = "idx", description = "게시글 번호", in = ParameterIn.PATH)
           @PathVariable String idx) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if(idx == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put("issue_idx", idx.toString());

            Map<String, Object> detail = boardService.selectBoardDetail(paramMap);

            if(detail == null || detail.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("result", detail);

            List<Map> reply = boardService.selectBoardReply(paramMap);

            rtnMap.put("reply", reply);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "파일 업로드")
    @RequestMapping(
            path = "/api/v1/board/upload",
            method = RequestMethod.POST,
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> uploadFile(HttpServletRequest request,
                                        @RequestPart MultipartFile multipartFile, @RequestParam String idx) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        log.info(multipartFile);
        try {
////            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
////            if (null == jwtMap) {
////                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
////            }
////            if (idx == null) {
////                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
////            }
//            Map<String, Object> paramMap = new HashMap<>();
////            paramMap.put("user_idx", jwtMap.get("cpn_idx"));
//            paramMap.put("user_idx", 1);
//            paramMap.put("issue_idx", replyDTO.getIssueIdx());
//            paramMap.put("reply_content", replyDTO.getReplyContent());


//            int result = boardService.insertReply(paramMap);

            String path = s3Util.uploadSingleFile(multipartFile, "board/");

            log.info(path);

//            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2124));
//            }

//            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "댓글 리스트")
    @GetMapping("/api/v1/admin/reply/list/{pageNo}")
    public ResponseEntity<?> getReplyList(HttpServletRequest request,
          @Parameter(required = true, description = "게시글 번호", in = ParameterIn.PATH, name = "pageNo")
          @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if(pageNo == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("pageNo", pageNo);

            Paging paging = boardService.setReplyPaging(jwtMap);
            List<Map> result = boardService.selectReply(jwtMap);

            if(result == null || result.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("paging", paging);
            rtnMap.put("result", result);

            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "댓글 검색")
    @GetMapping("/api/v1/admin/reply/search/{word}/{pageNo}")
    public ResponseEntity<?> searchReplyList(HttpServletRequest request,
          @Parameter(required = true, description = "검색어", in = ParameterIn.PATH, name = "word")
          @PathVariable String word,
          @Parameter(required = true, description = "게시글 번호", in = ParameterIn.PATH, name = "pageNo")
          @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {

            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if(pageNo == null || word == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("pageNo", pageNo);
            jwtMap.put("word", word);

            Paging paging = boardService.setReplyPaging(jwtMap);
            List<Map> result = boardService.selectReply(jwtMap);

            if(result == null || result.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2121));
            }

            rtnMap.put("paging", paging);
            rtnMap.put("result", result);

            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

}
