package kr.co.dk.sample.api.common.push.repository;

import kr.co.dk.sample.api.common.push.entity.Push;
import org.apache.ibatis.annotations.Mapper;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface PushRepository {
    List<Push> findTop100BySentIsFalseAndToBeSentAtIsBefore(LocalDateTime toBeSentAt);
}

