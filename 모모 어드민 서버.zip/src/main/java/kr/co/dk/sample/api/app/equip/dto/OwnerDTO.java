package kr.co.dk.sample.api.app.equip.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class OwnerDTO {
    private int ownerIdx;
    private String ownerName;
    private String ownerCareer;
    private String ownerPhone;
    private String ownerAddress;
    private MultipartFile ownerImage;
    private String originalFile; // 수정 시 사용
    private String ownerCategory;
}
