package kr.co.dk.sample.api.app.banner.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class BannerDTO {
    private int bannerIdx;
    private String bannerName;
    private MultipartFile bannerImage;
    private String originalFile;
    private String bannerTo;
    private int bannerOrder;
    private int bannerStatus;
}
