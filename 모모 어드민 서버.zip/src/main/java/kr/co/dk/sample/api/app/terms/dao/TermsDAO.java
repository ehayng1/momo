package kr.co.dk.sample.api.app.terms.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class TermsDAO {

    private static final Logger log = LogManager.getLogger(TermsDAO.class);

    static final String NAMESAPCE =  "kr.co.dk.sample.api.app.terms.mapper.TermsDAO.";

    //	@Autowired
    private SqlSession sqlSession;

    //	@Qualifier("readOnlySqlSession")
    private SqlSessionTemplate readOnlySqlSession;

    public TermsDAO(SqlSession sqlSession,SqlSessionTemplate readOnlySqlSession){
        this.sqlSession = sqlSession;
        this.readOnlySqlSession = readOnlySqlSession;
    }

    @Autowired
    Environment env;

    public Map<String, Object> selectTermsCnt(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectTermsCnt:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectTermsCnt", map);

        return result;
    }

    public List<Map> getTermsList(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ getTermsList:::");
        List<Map> laborList = readOnlySqlSession.selectList(NAMESAPCE + "getTermsList", map);
        return laborList;
    }

    public Map<String, Object> getTermsDetail(Map<String, Object> map) throws Exception{
        log.debug("+++++++++++++++++++++++++++++++++++++ getTermsDetail:::");
        Map<String,Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "getTermsDetail", map);

        return result;
    }

    public int updateTerms(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateTerms:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateTerms", map);

        return result;
    }

}
