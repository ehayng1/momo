package kr.co.dk.sample.api.app.alarm.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.co.dk.sample.api.app.alarm.service.AlarmService;
import kr.co.dk.sample.api.app.alarm.service.AndroidPushNotificationsService;
import kr.co.dk.sample.api.common.model.ApiResponse;
import kr.co.dk.sample.api.common.model.ErrorCode;
import kr.co.dk.sample.api.config.security.JwtTokenProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Tag(name="알림")
@RestController
public class AlarmController {

    private static final Logger log = LogManager.getLogger(AlarmController.class);

    @Autowired
    AlarmService alarmService;

    @Autowired
    JwtTokenProvider jwtTokenProvider;

    @Autowired
    AndroidPushNotificationsService androidPushNotificationsService;

    @Operation(summary = "알림 목록")
    @GetMapping("/api/v1/admin/push/list/{pageNo}")
    public ResponseEntity<?> getPushList(HttpServletRequest request,
                                         @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
                                         @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (null == pageNo) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("pageNo", pageNo);
            List<Map> result = alarmService.selectAlarmList(jwtMap);

            rtnMap.put("result", result);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "알림 발송")
    @PostMapping("/api/v1/admin/push/send")
    public ResponseEntity<?> sendPush(@Schema(
            description = "type, idx(only type = 'each'), title, content",
            type = "array",
            example = " {" +
                    "\"type\" :\"all, each\"" +
                    "\"idx\" :\"1, 2, 3, 4, ...\"" +
                    "\"title\" :\"알림제목\"" +
                    "\"content\" :\"알림내용\"" +
                    "}")
            @RequestBody Map<String, Object> paramMap, HttpServletRequest request) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            if (null == paramMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            List<String> notifications = alarmService.PeriodicNotificationJson(paramMap);

            if (notifications == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2107));
            }

            for (int i = 0; i < notifications.size(); i++) {
                HttpEntity<String> rtnRequest = new HttpEntity<>(notifications.get(i).toString());

                CompletableFuture<String> pushNotification = androidPushNotificationsService.send(rtnRequest);
                CompletableFuture.allOf(pushNotification).join();

                try{
                    String firebaseResponse = pushNotification.get();
                }
                catch (InterruptedException e){
                    log.debug("got interrupted!");
                    throw new InterruptedException();
                }
                catch (ExecutionException e){
                    log.debug("execution error!");
                }
            }


            int result = alarmService.insertPush(paramMap);

            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "푸시 테스트")
    @GetMapping("/api/v1/admin/push/test")
    public ResponseEntity pushTest(String token, String body, String title){
        HashMap<String, String> data = new HashMap<>();
        data.put("teste","zz");
        boolean success = alarmService.sendMessage(token, title,body,data);
        return ResponseEntity.ok(success);
    }

}
