package kr.co.dk.sample.api.app.equip.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class EquipDAO {

    private static final Logger log = LogManager.getLogger(EquipDAO.class);
    static final String NAMESAPCE =  "kr.co.dk.sample.api.app.equip.mapper.EquipDAO.";

    //	@Autowired
    private SqlSession sqlSession;

    //	@Qualifier("readOnlySqlSession")
    private SqlSessionTemplate readOnlySqlSession;

    public EquipDAO(SqlSession sqlSession,SqlSessionTemplate readOnlySqlSession){
        this.sqlSession = sqlSession;
        this.readOnlySqlSession = readOnlySqlSession;
    }

    @Autowired
    Environment env;

    public Map<String, Object> selectEquipCnt(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectEquipCnt:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectEquipCnt", map);

        return result;
    }

    public List<Map> selectEquipList(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectEquipList:::");
        List<Map> result = readOnlySqlSession.selectList(NAMESAPCE + "selectEquipList", map);

        return result;
    }

    public Map<String, Object> selectEquipDetail(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectEquipDetail:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectEquipDetail", map);

        return result;
    }

    public int updateRental(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateRental:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateRental", map);

        return result;
    }

    public int updateLease(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateLease:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateLease", map);

        return result;
    }

    public int updateEquip(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateEquip:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateEquip", map);

        return result;
    }

    public int insertEquipLease(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ insertEquipLease:::");
        int result = readOnlySqlSession.insert(NAMESAPCE + "insertEquipLease", map);

        return result;
    }

    public int deleteEquip(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ deleteEquip:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "deleteEquip", map);

        return result;
    }


    public Map<String, Object> selectOwnerCnt(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectOwnerCnt:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectOwnerCnt", map);

        return result;
    }

    public List<Map> selectOwnerList(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectOwnerList:::");
        List<Map> result = readOnlySqlSession.selectList(NAMESAPCE + "selectOwnerList", map);

        return result;
    }

    public Map<String, Object> selectOwnerDetail(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ selectOwnerDetail:::");
        Map<String, Object> result = readOnlySqlSession.selectOne(NAMESAPCE + "selectOwnerDetail", map);

        return result;
    }

    public int updateOwner(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ updateOwner:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "updateOwner", map);

        return result;
    }

    public int deleteOwner(Map<String, Object> map) throws Exception {
        log.debug("+++++++++++++++++++++++++++++++++++++ deleteOwner:::");
        int result = readOnlySqlSession.update(NAMESAPCE + "deleteOwner", map);

        return result;
    }

}
