package kr.co.dk.sample.api.app.labor.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
//import io.swagger.v3.oas.annotations.responses.ApiResponse;;
import kr.co.dk.sample.api.app.labor.dto.LaborDTO;
import kr.co.dk.sample.api.app.labor.service.LaborService;
import kr.co.dk.sample.api.common.model.ApiResponse;
import kr.co.dk.sample.api.common.model.ErrorCode;
import kr.co.dk.sample.api.common.model.Paging;
import kr.co.dk.sample.api.common.util.S3Util;
import kr.co.dk.sample.api.config.security.JwtTokenProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static kr.co.dk.sample.api.common.util.CommonUtil.makeForeach;

@Tag(name = "노무")
@RestController
public class LaborController {

    private static final Logger log = LogManager.getLogger(LaborController.class);

    @Autowired
    LaborService laborService;

    @Autowired
    JwtTokenProvider jwtTokenProvider;

    @Autowired
    S3Util s3Util;

    @Operation(summary = "노무 목록")
    @GetMapping(path="/api/v1/admin/labor/list/{pageNo}")
    public ResponseEntity<?> selectLaborList(HttpServletRequest request,
     @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
     @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (pageNo == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            // 노무 목록 조회 -- 체크리스트 항목 아직 적용되어있지 않음!!! ... JY
            Map<String, Object> paramMap = new HashMap<>();
//            paramMap.put("category", category.toString());
            paramMap.put("pageNo", pageNo);

            Paging pagingBoard = laborService.setLaborPaging(paramMap);
            List<Map> laborList = laborService.selectLaborList(paramMap);

            rtnMap.put("result", laborList);
            rtnMap.put("paging", pagingBoard);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "노무 검색")
    @GetMapping(path="/api/v1/admin/labor/search/{word}/{pageNo}")
    public ResponseEntity<?> searchLaborList(
            HttpServletRequest request,
            @Parameter(name = "word", description = "검색어", in = ParameterIn.PATH)
            @PathVariable String word,
            @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
            @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (pageNo == null || word == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            // 노무 목록 조회 -- 체크리스트 항목 아직 적용되어있지 않음!!! ... JY
            Map<String, Object> paramMap = new HashMap<>();
//            paramMap.put("category", category.toString());
            paramMap.put("pageNo", pageNo);
            paramMap.put("word", word);

            Paging pagingBoard = laborService.setLaborPaging(paramMap);
            List<Map> laborList = laborService.selectLaborList(paramMap);

            rtnMap.put("result", laborList);
            rtnMap.put("paging", pagingBoard);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "노무 상세")
    @GetMapping(path="/api/v1/admin/labor/detail/{idx}")
    public ResponseEntity<?> selectLaborDetail(HttpServletRequest request,
                                             @Parameter(name = "idx", description = "페이지 번호", in = ParameterIn.PATH)
                                             @PathVariable String idx) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (idx == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("idx", idx);

            Map<String, Object> result = laborService.selectLaborDetail(jwtMap);

            rtnMap.put("result", result);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "노무사 추가")
    @PostMapping("/api/v1/admin/labor/add")
    public ResponseEntity<?> insertLabor(HttpServletRequest request, @Parameter(required = true) LaborDTO laborDTO) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (laborDTO == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("laborDTO", laborDTO);
            String path = "";
            if(laborDTO.getLaborImage() != null) {
                path = s3Util.uploadSingleFile(laborDTO.getLaborImage(), "labor/");
                log.info(path + "1");
            }
            jwtMap.put("laborImage", path);

            log.info(path + "2");

            int result = laborService.insertLabor(jwtMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9989));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "노무사 수정")
    @PostMapping("/api/v1/admin/labor/update")
    public ResponseEntity<?> updateLabor(HttpServletRequest request, @Parameter(required = true) LaborDTO laborDTO) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (laborDTO == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("laborDTO", laborDTO);
            String path = "";
            if(laborDTO.getLaborImage() != null) {
                path = s3Util.uploadSingleFile(laborDTO.getLaborImage(), "labor/");
                log.info(path + "1");
            } else {
                path = laborDTO.getOriginalFile();
            }
            jwtMap.put("laborImage", path);

            log.info(path + "2");

            int result = laborService.updateLabor(jwtMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9991));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "노무사 삭제")
    @PostMapping("/api/v1/admin/labor/delete")
    public ResponseEntity<?> deleteLabor(
            @Schema(
                    description = "laborIdx",
                    type = "array",
                    example = " {\"idx\" :\"1, 2, 3, ...\"}")
            @RequestBody Map<String, Object> paramMap, HttpServletRequest request) {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            paramMap.put("list", makeForeach(paramMap.get("idx").toString()));

            int result = laborService.deleteLabor(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9990));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "타입 전체목록")
    @GetMapping(path="/api/v1/admin/labor/type/all")
    public ResponseEntity<?> getAllTypeList(HttpServletRequest request) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }

            List<Map> result = laborService.getAllTypeList();

            rtnMap.put("result", result);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "타입 목록")
    @GetMapping(path="/api/v1/admin/labor/typeList/{pageNo}")
    public ResponseEntity<?> getTypeList(HttpServletRequest request,
                                         @Parameter(name = "pageNo", description = "페이지 번호", in = ParameterIn.PATH)
                                         @PathVariable String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (pageNo == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            jwtMap.put("pageNo", pageNo);

            Paging paging = laborService.setTypePaging(jwtMap);
            List<Map> result = laborService.getTypeList(jwtMap);

            rtnMap.put("result", result);
            rtnMap.put("paging", paging);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "타입 추가")
    @PostMapping(path="/api/v1/admin/labor/typeList/add")
    public ResponseEntity<?> addType(@Schema(
            description = "laborIdx",
            type = "array",
            example = " {\"name\" :\"산재확인\"}")
                                             @RequestBody Map<String, Object> paramMap, HttpServletRequest request) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            int result = laborService.addType(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9990));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "타입 수정")
    @PostMapping(path="/api/v1/admin/labor/type/update")
    public ResponseEntity<?> updateType(@Schema(
            description = "idx, status(0 / 1)",
            type = "array",
            example = " {" +
                        "\"idx\" :\"1, 2, 3, ...\"" +
                        "\"status\" :\"0\"" +
                        "}")
            @RequestBody Map<String, Object> paramMap, HttpServletRequest request) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            paramMap.put("list", makeForeach(paramMap.get("idx").toString()));

            int result = laborService.updateType(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9990));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

}
