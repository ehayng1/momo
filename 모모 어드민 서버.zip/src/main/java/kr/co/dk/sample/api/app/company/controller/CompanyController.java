package kr.co.dk.sample.api.app.company.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.co.dk.sample.api.app.company.dto.CompanyDTO;
import kr.co.dk.sample.api.app.company.dto.RatingDTO;
import kr.co.dk.sample.api.app.company.dto.SiteDTO;
import kr.co.dk.sample.api.app.company.service.CompanyService;
import kr.co.dk.sample.api.common.model.ApiResponse;
import kr.co.dk.sample.api.common.model.ErrorCode;
import kr.co.dk.sample.api.common.model.Paging;
import kr.co.dk.sample.api.common.util.S3Util;
import kr.co.dk.sample.api.config.security.JwtTokenProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static kr.co.dk.sample.api.common.util.CommonUtil.makeForeach;

@Tag(name="건설사/현장")
@RestController
public class CompanyController {

    private static final Logger log = LogManager.getLogger(CompanyController.class);

    @Autowired
    CompanyService companyService;

    @Autowired
    JwtTokenProvider jwtTokenProvider;

    @Autowired
    S3Util s3Util;

    @Operation(summary = "건설사 목록", description = "")
    @GetMapping("/api/v1/admin/company/list/{pageNo}")
    public ResponseEntity<?> selectAllCompany(HttpServletRequest request, @PathVariable(name = "pageNo") String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (null == pageNo) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            jwtMap.put("pageNo", pageNo);
            Paging paging = companyService.setCompanyPaging(jwtMap);
            List<Map> companyList = companyService.selectAllCompany(jwtMap);

            if (companyList == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2101));
            }
            rtnMap.put("paging", paging);
            rtnMap.put("result", companyList);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "건설사 검색", description = "")
    @GetMapping("/api/v1/admin/company/search/{word}/{pageNo}")
    public ResponseEntity<?> selectSearchCompany(HttpServletRequest request, @PathVariable(name = "word") String word, @PathVariable(name = "pageNo") String pageNo) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (null == pageNo || null == word) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            jwtMap.put("word", word);
            jwtMap.put("pageNo", pageNo);
            Paging paging = companyService.setCompanyPaging(jwtMap);
            List<Map> companyList = companyService.selectAllCompany(jwtMap);

            if (companyList == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2101));
            }
            rtnMap.put("paging", paging);
            rtnMap.put("result", companyList);
            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "건설사 등록")
    @PostMapping("/api/v1/admin/company/add")
    public ResponseEntity<?> writeCompany(HttpServletRequest request, @Parameter(required = true) CompanyDTO companyDTO) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (companyDTO == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            jwtMap.put("companyDTO", companyDTO);
            String path = "";
            if(companyDTO.getCompany_logo() != null) {
                path = s3Util.uploadSingleFile(companyDTO.getCompany_logo(), "company/");
                log.info(path + "1");
            }
            jwtMap.put("companyLogo", path);

            log.info(path + "2");

            int result = companyService.writeCompany(jwtMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9989));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "건설사 수정")
    @PutMapping("/api/v1/admin/company/update")
    public ResponseEntity<?> updateCompany(HttpServletRequest request, @Parameter(required = true) CompanyDTO companyDTO) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (companyDTO == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            jwtMap.put("companyDTO", companyDTO);
            String path = "";
            if(companyDTO.getCompany_logo() != null) {
                path = s3Util.uploadSingleFile(companyDTO.getCompany_logo(), "company/");
                log.info(path + "1");
            } else {
                path = companyDTO.getOriginal_logo();
            }
            jwtMap.put("companyLogo", path);

            log.info(path + "2");

            int result = companyService.updateCompany(jwtMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9991));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "건설사 삭제")
    @PostMapping("/api/v1/admin/company/delete")
    public ResponseEntity<?> deleteCompany(
            @Schema(
                    description = "companyIdx",
                    type = "array",
                    example = " {\"idx\" :\"1, 2, 3, ...\"}")
            @RequestBody Map<String, Object> paramMap, HttpServletRequest request) {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            paramMap.put("list", makeForeach(paramMap.get("idx").toString()));

            int result = companyService.deleteCompany(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9990));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }



    @Operation(summary = "건설사 상세 정보", description = "")
    @GetMapping(path="/api/v1/admin/company/detail/{idx}")
    public ResponseEntity<?> selectCompanyInfo(HttpServletRequest request, @PathVariable(name = "idx") String idx) throws Exception {
        log.info("=============================START========================================== in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
//        Object obj = new Object();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (idx == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            Map<String, Object> paramMap = new HashMap<>();
//            paramMap.put("cpn_idx", jwtMap.get("cpn_idx"));
            paramMap.put("cpn_idx", idx);
            // 건설사 기본정보, 종합순위는 추후 추가해야함.
            Map<String, Object> companyInfo = companyService.selectCompanyInfo(paramMap);

            if (companyInfo == null || companyInfo.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2101));
            }

            rtnMap.put("result", companyInfo);

            // 현장리스트
//            List<Map> siteList = companyService.selectCompanySiteList(paramMap);
//
//            rtnMap.put("siteList", siteList);

            // 세부가평가
//            Map<String, Object> evaluate = companyService.selectCompanyEvaluate(paramMap);
//
//            rtnMap.put("evaluate", evaluate);

            // 현장평가 리스트
//            List<Map> ratingList = companyService.selectCompanyRatingList(paramMap);
//
//            rtnMap.put("ratingList", ratingList);

            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "건설사 현장 리스트")
    @GetMapping(path="/api/v1/admin/company/site/list/{companyIdx}")
    public ResponseEntity<?> getCompanySiteList(HttpServletRequest request, @PathVariable(name = "companyIdx") String companyIdx) throws Exception {
        log.info("=============================START========================================== in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (companyIdx == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            Map<String, Object> paramMap = new HashMap<>();
//            paramMap.put("cpn_idx", jwtMap.get("cpn_idx"));
            paramMap.put("cpn_idx", companyIdx);
            // 현장 리스트
            List<Map> siteList = companyService.selectCompanySiteList(paramMap);

            if (siteList == null || siteList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2102));
            }

            rtnMap.put("result", siteList);

            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "현장 리스트")
    @GetMapping(path="/api/v1/admin/site/list/{pageNo}")
    public ResponseEntity<?> getSiteList(HttpServletRequest request, @PathVariable(name = "pageNo") String pageNo) throws Exception {
        log.info("=============================START========================================== in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (pageNo == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            jwtMap.put("pageNo", pageNo);
            Paging paging = companyService.setSitePaging(jwtMap);
            // 현장 리스트
            List<Map> siteList = companyService.selectSiteList(jwtMap);

            if (siteList == null || siteList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2102));
            }

            rtnMap.put("paging", paging);
            rtnMap.put("result", siteList);

            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "현장 검색")
    @GetMapping(path="/api/v1/admin/site/search/{word}/{pageNo}")
    public ResponseEntity<?> getSiteSearchList(HttpServletRequest request, @PathVariable(name = "word") String word, @PathVariable(name = "pageNo") String pageNo) throws Exception {
        log.info("=============================START========================================== in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (pageNo == null || word == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            jwtMap.put("pageNo", pageNo);
            jwtMap.put("word", word);
            Paging paging = companyService.setSitePaging(jwtMap);
            // 현장 리스트
            List<Map> siteList = companyService.selectSiteList(jwtMap);

            if (siteList == null || siteList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2102));
            }

            rtnMap.put("paging", paging);
            rtnMap.put("result", siteList);

            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "평가 리스트")
    @GetMapping("/api/v1/admin/rating/list/{pageNo}")
    public ResponseEntity<?> selectRatingList(HttpServletRequest request, @PathVariable(name = "pageNo") String pageNo) throws Exception {
        log.info("=============================START========================================== in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (pageNo == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            Map<String, Object> paramMap = new HashMap<>();
//            paramMap.put("cpn_idx", jwtMap.get("cpn_idx"));
            paramMap.put("pageNo", pageNo);

            Paging paging = companyService.setRatingPaging(paramMap);
            // 현장 리스트
            List<Map> result = companyService.selectRatingList(paramMap);

            if (result == null || result.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2102));
            }

            rtnMap.put("paging", paging);
            rtnMap.put("result", result);

            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }


    @Operation(summary = "평가 검색")
    @GetMapping("/api/v1/admin/rating/search/{word}/{pageNo}")
    public ResponseEntity<?> selectRatingSearchList(HttpServletRequest request, @PathVariable(name = "pageNo") String pageNo, @PathVariable(name = "word") String word) throws Exception {
        log.info("=============================START========================================== in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (pageNo == null || word == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            Map<String, Object> paramMap = new HashMap<>();
//            paramMap.put("cpn_idx", jwtMap.get("cpn_idx"));
            paramMap.put("pageNo", pageNo);
            paramMap.put("word", word);

            Paging paging = companyService.setRatingPaging(paramMap);
            // 현장 리스트
            List<Map> result = companyService.selectRatingList(paramMap);

            if (result == null || result.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2102));
            }

            rtnMap.put("paging", paging);
            rtnMap.put("result", result);

            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }


    @Operation(summary = "현장 등록")
    @PostMapping("/api/v1/admin/site/write")
    public ResponseEntity<?> writeSite(HttpServletRequest request, @Parameter(required = true)SiteDTO siteDTO) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (siteDTO == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            jwtMap.put("siteDTO", siteDTO);
            String path = "";
            if(siteDTO.getSite_picture() != null) {
                path = s3Util.uploadSingleFile(siteDTO.getSite_picture(), "site/");
                log.info(path + "1");
            }
            jwtMap.put("sitePicture", path);

            log.info(path + "2");

            int result = companyService.writeSite(jwtMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9989));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "현장 수정")
    @PutMapping("/api/v1/admin/site/update")
    public ResponseEntity<?> updateSite(HttpServletRequest request, @Parameter(required = true) SiteDTO siteDTO) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (siteDTO == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            jwtMap.put("siteDTO", siteDTO);
            String path = "";
            if(siteDTO.getSite_picture() != null) {
                path = s3Util.uploadSingleFile(siteDTO.getSite_picture(), "site/");
                log.info(path + "1");
            } else {
                path = siteDTO.getOriginal_file();
            }
            jwtMap.put("sitePicture", path);

            log.info(path + "2");

            int result = companyService.updateSite(jwtMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9991));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "건설사 삭제")
    @PostMapping("/api/v1/admin/site/delete")
    public ResponseEntity<?> deleteSite(
            @Schema(
                    description = "siteIdx",
                    type = "array",
                    example = " {\"idx\" :\"1\"}")
            @RequestBody Map<String, Object> paramMap, HttpServletRequest request) {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            paramMap.put("list", makeForeach(paramMap.get("idx").toString()));

            int result = companyService.deleteSite(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9990));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }



    @Operation(summary = "현장 상세정보")
    @GetMapping(path="/api/v1/admin/site/detail/{siteIdx}")
    public ResponseEntity<?> selectSiteDetail(HttpServletRequest request, @PathVariable(name = "siteIdx") String siteIdx) throws Exception {
        log.info("=============================START========================================== in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (siteIdx == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }
            Map<String, Object> paramMap = new HashMap<>();
//            paramMap.put("cpn_idx", jwtMap.get("cpn_idx"));
            paramMap.put("site_idx", siteIdx);
            // 현장 상세정보
            Map<String, Object> siteInfo = companyService.selectSiteInfo(paramMap);

            if (siteInfo == null || siteInfo.isEmpty()) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_2102));
            }

            rtnMap.put("result", siteInfo);

            // 현장 평가 리스트
//            List<Map> ratingList = companyService.selectSiteRatingList(paramMap);

//            rtnMap.put("ratingList", ratingList);

            return ResponseEntity.ok(new ApiResponse(true, rtnMap, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }
    }

    @Operation(summary = "현장 평가 삭제")
    @PostMapping(path="/api/v1/admin/rating/delete")
    public ResponseEntity<?> deleteRating(
            @Schema(
                    description = "ratingIdx",
                    type = "array",
                    example = " {\"idx\" :\"1\"}")
            @RequestBody Map<String, Object> paramMap, HttpServletRequest request) throws Exception {
        log.info("=============================START========================================= in " + request.getRequestURL());
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        try {
            Map<String, Object> jwtMap = jwtTokenProvider.getJwtInfo(request);
            if (null == jwtMap) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_1104));
            }
            if (paramMap == null) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9002));
            }

            paramMap.put("list", makeForeach(paramMap.get("idx").toString()));

            int result = companyService.deleteRating(paramMap);

            if(result <= 0) {
                return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_9990));
            }

            return ResponseEntity.ok(new ApiResponse(true, "success", 200));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new ApiResponse(ErrorCode.CODE_500));
        }

    }
}
