// let url = 'https://admin.api.buildmomo.com/api/v1/admin/';
let url = '/api/v1/admin/';
// let url = 'http://localhost:8088/api/v1/admin/'

export const BASE_URL = url
