import React from 'react'

class Paging extends React.PureComponent {
	render() {
		return (
			<></>
		)
	}
}

export default Paging