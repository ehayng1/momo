import React from 'react'
import api from '../../api/api';
import axios from 'axios';
import Spinner from '../../components/Spinner';
import moment from 'moment';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';

class Member extends React.PureComponent {

    constructor(props) {
        super(props)
        this.state = {
            isLoading: false,
            pageNo: 1,
            list: [],
            paging: {},
            word: '',
            search: false,
            redirect: null
        }
    }

    async componentDidMount() {
        this.getList()
    }

    handleChange = e => {
        this.setState({
            [e.target.name]: e.target.value
        }, () => {
            if (this.state.word.length === 0 && this.state.search) {
                this.setState({
                    pageNo: 1,
                    search: false,
                })
                this.getList()
            }
        })
    }

    handlePageNo = val => {
        this.setState({
            pageNo: val
        }, () => {
            if (this.state.search) {
                this.onSearch()
            } else {
                this.getList()
            }
        })
    }

    checkEnter = e => {
        if (e.code === 'Enter') {
            this.onSearch()
        }
    }

    checkPrev = () => {
        const {pageNo, search} = this.state
        if (pageNo > 1) {
            this.setState({
                pageNo: pageNo - 1
            }, () => {
                if (search) {
                    this.onSearch()
                } else {
                    this.getList()
                }
            })
        }
    }

    checkNext = () => {
        const {pageNo, search, paging} = this.state
        if (pageNo < paging.finalPageNo) {
            this.setState({
                pageNo: pageNo + 1
            }, () => {
                if (search) {
                    this.onSearch()
                } else {
                    this.getList()
                }
            })
        }
    }

    getList = async () => {
        await this.setState({
            isLoading: true
        }, () => {
            try {
                const config = {
                    headers: {
                      'Content-Type': 'application/json',
                      'Access-Control-Allow-Origin': '*',
                      'Access-Control-Allow-Headers': '*',
                      'authorization': `Bearer ${this.props.token}`
                    },
                  };
                api.get(`user/list/${this.state.pageNo}`, config).then((result) => {
                    console.log(result)
                    if(result.data.success) {
                        let list = result.data.data.result
                        list = list.map(val => {
                                val.isChecked = false
                            val.timestamp_create = moment(val.timestamp_create).format('YYYY-MM-DD')
                            if (typeof val.user_location === 'undefined') {
                                return val
                            }
                            val.user_location = String(val.user_location).replace(/\:/g, ', ')
                            return val
                        })
                        this.setState({
                            paging: result.data.data.paging,
                            list: list,
                            isLoading: false
                        })
                    } else {
                        alert(result.data.message)
                    }
                })
            } catch (err) {
                alert('서버와 통신에 실패');
                console.log('err', err);
            } finally {
                this.setState({isLoading: false})
            }
        })
    }

    onSearch = async () => {
        if (this.state.word.trim().length <= 0) {
            alert('검색어를 입력해주세요.')
            return false
        }
        await this.setState({
            isLoading: true
        }, () => {
            try {
                const config = {
                    headers: {
                      'Content-Type': 'application/json',
                      'Access-Control-Allow-Origin': '*',
                      'Access-Control-Allow-Headers': '*',
                      'authorization': `Bearer ${this.props.token}`
                    },
                  };
                api.get(`user/search/${this.state.word}/${this.state.pageNo}`, config).then((result) => {
                    console.log(result)
                    if(result.data.success) {
                        if (result.data.data.result.length > 0) {                            
                            let list = result.data.data.result
                            list = list.map(val => {
                                val.isChecked = false
                                val.timestamp_create = moment(val.timestamp_create).format('YYYY-MM-DD')
                                if (typeof val.user_location === 'undefined') {
                                    return val
                                }
                                val.user_location = String(val.user_location).replace(/\:/g, ', ')
                                return val
                            })
                            this.setState({
                                paging: result.data.data.paging,
                                list: list,
                                isLoading: false,
                                search: true
                            })
                        } else {
                            alert('검색 결과가 없습니다.')
                            if (this.state.search) {
                                this.setState({
                                    pageNo: 1,
                                    search: false
                                }, () => this.getList())
                            }
                            return
                        }
                    } else {
                        alert(result.data.message)
                    }
                })
            } catch (err) {
                alert('서버와 통신에 실패');
                console.log('err', err);
            } finally {
                this.setState({isLoading: false})
            }
        })
    }

    
    render() {
        const { paging, pageNo, redirect } = this.state
        
        const handlePageNo = this.handlePageNo

        function getPaging() {
            let arr = []
            if (paging) {
                for(let i = paging.firstPageNo; i <= paging.finalPageNo; i++) {
                    arr.push(
                        <li className={pageNo === i ? "on" : null}>
                            <button onClick={() => handlePageNo(i)} name="pageNo" value={i}>
                                {i}
                            </button>
                        </li>
                    )
                }
            }
            return arr
        }

        return (
        <>
            <div className="content">
                <h2>회원현황</h2>
                <div className="location">
                    <span>회원관리</span>
                    <span>회원현황</span>
                </div>
                <div className="search">
                    <fieldset>
                        <label htmlFor="input_search">검색</label>
                        <input 
                            type="text" 
                            placeholder="휴대폰 / 지역 / 블록체인번호" 
                            name='word' 
                            id="input_search" 
                            value={this.state.word} 
                            onChange={this.handleChange}
                            onKeyDown={this.checkEnter}
                        ></input>
                        <button type="button" onClick={this.onSearch}>검색</button>
                    </fieldset>
                </div>
                <div className="list">
                    <div className="scroll">
                        <table>
                            <caption>회원현황</caption>
                            <thead>
                                <tr>
                                    <th className="no">No.</th>
                                    <th>휴대폰 번호</th>
                                    <th className="tal">지역</th>
                                    <th className="tal">블록체인 번호</th>
                                    <th>가입날짜</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.list && this.state.list.map((val, idx) => {
                                        return (
                                            <tr>
                                                <td className="no">{val.user_idx}</td>
                                                <td>{val.user_phone}</td>
                                                <td className="tal">{val.user_location}</td>
                                                <td className="tal">{val.code_blockchain}</td>
                                                <td>{val.timestamp_create}</td>
                                            </tr>
                                        )
                                    })
                                }
                            </tbody>
                        </table>
                    </div>
                    <div className="paging">
                        <ul className="clearfix">
                            <li><button onClick={this.checkPrev}>이전 페이지</button></li>
                            {getPaging()}
                            <li><button onClick={this.checkNext}>다음 페이지</button></li>
                        </ul>
                    </div>
                </div>
                {this.state.isLoading && <Spinner />}
            </div>
            </>
        );
    }
}
const mapStateToProps = state => ({
    token: state.auth.user.sessionToken
})
export default connect(mapStateToProps)(Member);