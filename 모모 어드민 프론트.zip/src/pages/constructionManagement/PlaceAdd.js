import React from 'react';
import api from '../../api/api';
import axios from 'axios';
import Spinner from '../../components/Spinner';
import moment from 'moment';
import { connect } from 'react-redux';
import Modal from 'react-modal';
import DaumPost from '../../components/DaumPost'

class PlaceAdd extends React.PureComponent {

    constructor(props) {
        super(props)
        this.state = ({
            isLoading: false,
            isOpen: false,
            companyIdx: '',
            siteName: '',
            address: '',
            startDate: '',
            endDate: '',
            src: '',
            file: {}
        })
    }

    handleChange = e => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    handleDate = e => {
        let val = e.target.value
        val = val.replace('--', '-')
        if (val.match(/^\d{5}$/) !== null) {
            val = String(val).slice(0, 4) + '-' + String(val).slice(4, 5)
        } else if (val.match(/^\d{4}\-\d{3}$/) !== null) {
            val = String(val).slice(0, 7) + '-' + String(val).slice(7, 8)
        }
        this.setState({
            [e.target.name]: val
        })
    }

    handleFile = e => {
        if (e.target.files && e.target.files[0]) {
            const reader = new FileReader()
  
            reader.onload = e => {
              this.preview.src = e.target.result
            }
            reader.readAsDataURL(e.target.files[0])
  
            this.setState({file: e.target.files[0]})
          }
    }

    toggleIsOpen = () => this.setState({isOpen: !this.state.isOpen})

    handleAddress = data => {
        this.setState({
            isOpen: false,
            address: data.address
        })
    }

    onSubmit = async () => {
        const { siteName, address, startDate, endDate, file, src } = this.state
        if (siteName.trim().length === 0) {
            alert('현장명을 입력해주세요')
            return false
        } else if (address.trim().length === 0) {
            alert('주소를 입력해주세요')
            return false
        } else if (!moment(startDate).isValid()) {
            alert('시작일을 양식에 맞게 입력해주세요')
            return false
        } else if (!moment(endDate).isValid()) {
            alert('종료일을 양식에 맞게 입력해주세요')
            return false
        }
        await this.setState({
            isLoading: true
        }, () => {
            try {
                const config = {
                    headers: {
                      'Content-Type': 'application/json',
                      'Access-Control-Allow-Origin': '*',
                      'Access-Control-Allow-Headers': '*',
                      'authorization': `Bearer ${this.props.token}`
                    },
                };
                let formData = new FormData()
                formData.append('company_idx', this.props.match.params.idx)
                formData.append('site_name', siteName)
                formData.append('site_address', address)
                formData.append('site_period_start', startDate)
                formData.append('site_period_end', endDate)
                if (file.size !== undefined) {
                    formData.append('site_picture', file)
                }
                api.post(`site/write`, formData, config).then((result) => {
                    console.log(result)
                    if(result.data.success) {
                        alert('등록 성공')
                        this.props.history.goBack()
                    } else {
                        alert(result.data.message)
                    }
                })
            } catch (err) {
                alert('서버와 통신에 실패');
                console.log('err', err);
            } finally {
                this.setState({isLoading: false})
            }
        })
    }

    render() {
        const { siteName, address, startDate, endDate, src } = this.state
        return (
        <>
            <div className="content">
                <h2>현장 등록</h2>
                <div className="location">
                    <span>건설사관리</span>
                    <span>현장리스트</span>
                    <span>현장상세</span>
                </div>
                <div className="detail">
                    <table>
                        <caption>현장 상세</caption>
                        <tbody>
                            <tr>
                                <th>현장명</th>
                                <td>
                                    <input 
                                        type="text" 
                                        name="siteName" 
                                        value={siteName} 
                                        onChange={this.handleChange} 
                                        placeholder="현장 명" 
                                    />    
                                </td>
                            </tr>
                            <tr>
                                <th>현장 위치</th>
                                <td>
                                    <div className="address">
                                        <input 
                                            type="text" 
                                            name="address" 
                                            value={address} 
                                            onChange={this.handleChange} 
                                            placeholder="건설사 명" 
                                        />
                                        <button onClick={this.toggleIsOpen} className="btn btn2">주소찾기</button>
                                    </div>
                                </td>
                            </tr>
                            <tr className="start_date">
                                <th>시작일</th>
                                <td>
                                    <input 
                                        type="text" 
                                        name="startDate" 
                                        value={startDate} 
                                        onChange={this.handleDate} 
                                        placeholder="숫자만 입력" 
                                        className='size1'
                                        maxLength={10}
                                    />
                                </td>
                            </tr>
                            <tr className="end_date">
                                <th>종료일</th>
                                <td>
                                    <input 
                                        type="text" 
                                        name="endDate" 
                                        value={endDate} 
                                        onChange={this.handleDate} 
                                        placeholder="숫자만 입력" 
                                        className='size1'
                                        maxLength={10}
                                    />
                                </td>
                            </tr>
                            <tr>
                                <th>현장사진</th>
                                <td>
                                    <div className="img_box">
                                        <input 
                                            type="file" 
                                            style={{display: "none" }}
                                            name="file" 
                                            accept="image/*" 
                                            onChange={this.handleFile}
                                            ref={ref => this.fileInput = ref}
                                        /> 
                                        <img 
                                            src={require("../../img/place_img.png")} 
                                            ref={ref => this.preview = ref} 
                                            alt="현장사진"
                                        />
                                        <button 
                                            className="btn btn4 ml10" 
                                            onClick={() => this.fileInput.click()}
                                            style={{verticalAlign: 'top'}}
                                        >
                                            파일찾기
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <button onClick={this.onSubmit} className="btn btn3 w170 top_btn">등록하기</button>
                </div>
                {this.state.isLoading && <Spinner />}
                <Modal isOpen={this.state.isOpen} onRequestClose={this.toggleIsOpen}>
                    <DaumPost handleAddress={this.handleAddress} />
                </Modal>
            </div>
            </>
        );
    }
}
const mapStateToProps = state => ({
    token: state.auth.user.sessionToken
})
export default connect(mapStateToProps)(PlaceAdd);