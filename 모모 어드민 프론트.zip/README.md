# 건설모모 어드민 웹

### `npm install / yarn install`

라이브러리 설치

### `yarn start`

앱 구동

### 로컬서버 / AWS 서버 변경

src/api/url.js 변경