# 건설모모 앱 프론트엔드

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### 로컬서버 / AWS서버 세팅 변경
```
vue.config.js - devServer 부분 변경, port부분 전까지 주석으로 관리하면 됨
```
