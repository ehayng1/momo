export default {
  path: '/',
  component: () => import('../views/main/Index'),
  // redirect : ''
  meta: {
    keepAlive: false
  },
  children: [
    {
      path: '/',
      name: 'Main',
      component: () => import('@/views/main/Evaluation')
    },
    {
      path: 'equipment',
      name: 'Equipment',
      component: () => import('@/views/main/Equipment'),
      meta: {
        scroll: false
      }
    },

    {
      path: 'resources',
      name: 'HumanResources',
      component: () => import('@/views/main/HumanResources'),
      meta: {
        scroll: false
      }
    },
    {
      path: 'labor',
      name: 'Labor',
      component: () => import('@/views/main/Labor'),
      meta: {
        scroll: false
      }
    },
    {
      path: 'issue',
      name: 'Issue',
      component: () => import('@/views/main/Issue'),
      meta: {
        scroll: false
      }
    }
    // 필요시
  ]
}
