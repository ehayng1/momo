// let url = 'http://ec2-3-36-71-252.ap-northeast-2.compute.amazonaws.com/api/v1/'
// let url = 'http://localhost/api/v1/'
let url = '/api/v1/'
// let url = 'https://api.momobuild.com/api/v1/'
// let url = 'http://172.30.1.57/api/v1/'

export const BASE_URL = url
