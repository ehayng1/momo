<template>
  <div>에러페이지</div>
</template>

<script>
  export default {
    components: {}
  }
</script>
