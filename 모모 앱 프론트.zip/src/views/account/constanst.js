export const equipmentArr = [
  {
    selcted: {},
    list: [
      { name: '미니굴삭기', value: 0 },
      { name: '굴삭기', value: 1 },

      { name: '테이블리프트', value: 2 },
      { name: '크레인/카고크레인', value: 3 },
      { name: '지게차', value: 4 },
      { name: '스카이', value: 5 },
      { name: '로더', value: 6 },
      { name: '불도저', value: 7 },
      { name: '바브캣', value: 8 },
      { name: '덤프트럭', value: 9 },
      { name: '살수차', value: 10 },
      { name: '펌프카', value: 11 },
      { name: '도로포장 장비', value: 12 },
      { name: '고소작업 렌탈', value: 13 },
      { name: '기계임대 ', value: 14 }
    ]
  }
]
export const service = {
  zogong: [{ name: '일반관리자', selected: false }],
  gigong: [
    { name: '목수(목공)', selected: false },
    { name: '용접공', selected: false },
    { name: '설비', selected: false },
    { name: '조경', selected: false },

    { name: '미장공', selected: false },
    { name: '타일공', selected: false },
    { name: '석제', selected: false },
    { name: '조석공(쓰미)', selected: false },
    { name: '콘크리트공(타설)', selected: false },
    { name: '방수', selected: false },
    { name: '철근공', selected: false },
    { name: '전기', selected: false },
    { name: '로프공', selected: false },
    { name: '도장공(페인트공)', selected: false },
    { name: '기타', selected: false }
  ],
  middleService: [
    { name: '안전관리자', selected: false },
    { name: '신호수', selected: false },
    { name: '왓치맨', selected: false },
    { name: '화기감시자', selected: false }
  ],
  equimentAndNoMusa: [
    { id: 0, name: '장비주', selected: false },
    { id: 1, name: '노무사', selected: false }
  ]
}
