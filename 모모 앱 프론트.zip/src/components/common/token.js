var TOKEN_FCM = ''

// function getTokenFcm(token) {
//   alert(token)
//   TOKEN_FCM = token
//   return token
// }

var getTokenFcm = ''

export { TOKEN_FCM, getTokenFcm }
