const equip = [
  {
    value: 'all',
    text: '장비 전체'
  },
  {
    value: '미니굴삭기',
    text: '미니굴삭기'
  },
  {
    value: '굴삭기',
    text: '굴삭기'
  },
  {
    value: '테이블리프트',
    text: '테이블리프트'
  },
  {
    value: '크레인/카고크레인',
    text: '크레인/카고크레인'
  },
  {
    value: '지게차',
    text: '지게차'
  },
  {
    value: '스카이',
    text: '스카이'
  },
  {
    value: '로더',
    text: '로더'
  },
  {
    value: '불도저',
    text: '불도저'
  },
  {
    value: '바브캣',
    text: '바브캣'
  },
  {
    value: '덤프트럭',
    text: '덤프트럭'
  },
  {
    value: '살수차',
    text: '살수차'
  },
  {
    value: '펌프카',
    text: '펌프카'
  },
  {
    value: '사다리차',
    text: '사다리차'
  },
  {
    value: '천공기',
    text: '천공기'
  },
  {
    value: '도로포장 장비',
    text: '도로포장 장비'
  },
  {
    value: '고소작업 렌탈',
    text: '고소작업 렌탈'
  },
  {
    value: '기계임대',
    text: '기계임대'
  }
]

export default equip
