const shortArea = [
  {
    value: 'all',
    text: '지역 전체'
  },
  {
    value: '서울시',
    text: '서울시'
  },
  {
    value: '경기도',
    text: '경기도'
  },
  {
    value: '인천시',
    text: '인천시'
  },
  {
    value: '강원도',
    text: '강원도'
  },
  {
    value: '경상북도',
    text: '경상북도'
  },
  {
    value: '대구시',
    text: '대구시'
  },
  {
    value: '울산시',
    text: '울산시'
  },
  {
    value: '부산시',
    text: '부산시'
  },
  {
    value: '경상남도',
    text: '경상남도'
  },
  {
    value: '광주시',
    text: '광주시'
  },
  {
    value: '전라남도',
    text: '전라남도'
  },
  {
    value: '전라북도',
    text: '전라북도'
  },
  {
    value: '충청남도',
    text: '충청남도'
  },
  {
    value: '세종시',
    text: '세종시'
  },
  {
    value: '대전시',
    text: '대전시'
  },
  {
    value: '충청북도',
    text: '충청북도'
  },
  {
    value: '제주도',
    text: '제주도'
  }
]

export default shortArea
