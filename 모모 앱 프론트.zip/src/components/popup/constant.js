export const dataList = {
  bullying: [
    { content: '- 행위자(가해자)가 누군지 지목할 수 있다.', selected: false },
    { content: '- 보통의 업무처리상 통상적인 행위가 아니다', selected: false },

    {
      content: '- 체적인 증거(영상, 녹취록, 사진 등)가 있거나 수집이 가능하다',
      selected: false
    }
  ],
  interspersed: [
    {
      title: '산재확인',
      content: '- 근무시간내 상해를 (사고를) 당했다',
      selected: false
    },
    {
      title: '산재확인',
      content: '- 휴업이 3일이상(진단 4일 이상) 이다 ',
      selected: false
    },
    {
      title: '산재확인',
      content: '- 평소 가지고 있던 지병과 관계가 없는 상해이다',
      selected: false
    }
  ],
  wage: [
    {
      content: '- 급여, 퇴직금, 수당(휴일, 연장, 야근 등)이 미지급 되었다.',
      selected: false
    },
    {
      content:
        '- 근로계약서가 존재한다(또는 일정하게 금액이 지급된 통장 증명이 가능하다)',
      selected: false
    },
    { content: '- 임금이 미지급된지 3년이 지나지 않았다', selected: false }
  ]
}
