<template>
  <div class="terms">
    <modal
      name="terms"
      :scrollable="true"
      :resizable="false"
      :height="this.height * 0.6"
      :width="'80%'"
      :minWidth="this.width * 0.8"
      :minHeight="this.height * 0.6"
      :maxHeight="this.height * 0.6"
      :styles="'overflow-y: auto'"
    >
      <!-- <div
          style="width: 90%; background-color: brown; position: fixed"
          class="terms_close_modal"
        > -->
      <div class="terms_close_modal">
        <!-- X 버튼 -->
        <div
          style="
            width: 100%;
            height: 40px;
            display: flex;
            justify-content: right;
            background-color: white;
          "
        >
          <div @click="hide" class="close" />
        </div>
      </div>
      <div style="padding-top: 40px" v-html="termsContent" @click="hide" />

      <!-- {{ termsContent }}  -->
    </modal>
  </div>
</template>

<script>
  export default {
    name: 'MyComponent',
    data() {
      return {
        width: screen.width,
        height: screen.height
      }
    },
    methods: {
      show() {
        this.$modal.show('terms')
      },
      hide() {
        this.$modal.hide('terms')
      }
    },
    mount() {
      this.show()
    },
    props: {
      termsContent: {
        type: String,
        default: ''
      }
    }
  }
</script>
