<template>
  <footer class="page-footer">
    <address>
      서울특별시 송파구 올림픽로35다길 32 예전빌딩 9F (주)우아한청년들
    </address>
    <span class="copyright"
      >Copyright &copy;Woowa Youths Corp. All right Reserved</span
    >
  </footer>
</template>
