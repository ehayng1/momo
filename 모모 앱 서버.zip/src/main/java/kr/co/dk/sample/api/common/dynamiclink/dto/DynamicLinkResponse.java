package kr.co.dk.sample.api.common.dynamiclink.dto;

import lombok.Data;

@Data
public class DynamicLinkResponse {
    private String shortLink;
    private String previewLink;
}
