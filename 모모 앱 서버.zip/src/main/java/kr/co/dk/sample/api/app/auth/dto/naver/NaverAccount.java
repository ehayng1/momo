package kr.co.dk.sample.api.app.auth.dto.naver;

import lombok.Data;

@Data
public class NaverAccount {
    private NaverProfile profile;
}
