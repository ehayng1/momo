package kr.co.dk.sample.api.common.model.enums;

public interface CodeEnum<T> {
    T getValue();
}
