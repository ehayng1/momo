package kr.co.dk.sample.api.common.temp;

import lombok.Data;

@Data
public class SlackPayload {
    private String text;

//    public SlackPayload(String text){
//        this.text = text;
//    }
}
