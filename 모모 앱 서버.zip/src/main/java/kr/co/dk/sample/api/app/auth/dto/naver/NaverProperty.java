package kr.co.dk.sample.api.app.auth.dto.naver;

import lombok.Data;

@Data
public class NaverProperty {
    private String id;
    private String email;
    private String name;
}
